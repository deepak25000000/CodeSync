(() => {
  // src/shared/config.js
  var DEFAULT_API_BASE_URL = "http://127.0.0.1:8000";
  var API_PREFIX = "/api/v1";
  var PLATFORM_IDS = ["leetcode", "geeksforgeeks", "codechef", "neetcode"];
  var PLATFORM_LABELS = {
    leetcode: "LeetCode",
    geeksforgeeks: "GeeksforGeeks",
    codechef: "CodeChef",
    neetcode: "NeetCode"
  };
  var VERDICTS = ["accepted", "rejected", "pending", "manual", "unknown"];
  var REQUEST_TIMEOUT_MS = 15e3;

  // src/shared/api.js
  var ApiError = class extends Error {
    constructor(code, message, { status = null, cause = null } = {}) {
      super(message);
      this.name = "ApiError";
      this.code = code;
      this.status = status;
      if (cause) this.cause = cause;
    }
  };
  function normalizeError(body, status, statusText = "") {
    const fallbackCode = `HTTP_${status}`;
    const detail = body && typeof body === "object" ? body.detail : void 0;
    if (detail && typeof detail === "object" && !Array.isArray(detail)) {
      const code = typeof detail.code === "string" && detail.code ? detail.code : fallbackCode;
      const message2 = typeof detail.message === "string" && detail.message ? detail.message : `Request failed with status ${status}`;
      return { code, message: message2 };
    }
    if (typeof detail === "string" && detail) {
      return { code: fallbackCode, message: detail };
    }
    const message = statusText ? `${status} ${statusText}` : `Request failed with status ${status}`;
    return { code: fallbackCode, message };
  }
  function buildUrl(baseUrl, path) {
    const base = String(baseUrl || "").replace(/\/+$/, "");
    if (!base) throw new ApiError("NO_BASE_URL", "api base url is not configured");
    const suffix = path.startsWith("/") ? path : `/${path}`;
    return `${base}${API_PREFIX}${suffix}`;
  }
  function isAbortError(err) {
    return err && (err.name === "AbortError" || err.name === "TimeoutError" || err.code === 20 || err.code === "ABORT_ERR");
  }
  async function apiRequest(path, {
    method = "GET",
    baseUrl,
    token = null,
    body,
    headers = {},
    timeoutMs = REQUEST_TIMEOUT_MS,
    fetchImpl,
    signal
  } = {}) {
    const url = buildUrl(baseUrl, path);
    const doFetch = fetchImpl || (typeof globalThis.fetch === "function" ? globalThis.fetch.bind(globalThis) : null);
    if (!doFetch) throw new ApiError("NO_FETCH", "fetch is unavailable");
    const controller = new AbortController();
    let timedOut = false;
    let externallyAborted = false;
    const timer = setTimeout(() => {
      timedOut = true;
      controller.abort();
    }, timeoutMs);
    const onExternalAbort = () => {
      externallyAborted = true;
      controller.abort();
    };
    if (signal) {
      if (signal.aborted) onExternalAbort();
      else signal.addEventListener("abort", onExternalAbort, { once: true });
    }
    const finalHeaders = { Accept: "application/json", ...headers };
    if (token) finalHeaders.Authorization = `Bearer ${token}`;
    let payload;
    if (body !== void 0) {
      payload = JSON.stringify(body);
      finalHeaders["Content-Type"] = "application/json";
    }
    let response;
    try {
      response = await doFetch(url, {
        method,
        headers: finalHeaders,
        body: payload,
        signal: controller.signal
      });
    } catch (err) {
      if (timedOut) throw new ApiError("TIMEOUT", `request timed out after ${timeoutMs}ms`, { cause: err });
      if (externallyAborted) throw new ApiError("ABORTED", "request aborted", { cause: err });
      if (isAbortError(err)) throw new ApiError("ABORTED", "request aborted", { cause: err });
      throw new ApiError("NETWORK", err && err.message ? err.message : "network request failed", { cause: err });
    } finally {
      clearTimeout(timer);
      if (signal) signal.removeEventListener("abort", onExternalAbort);
    }
    if (!response.ok) {
      let parsed = null;
      const text2 = await response.text().catch(() => "");
      if (text2) {
        try {
          parsed = JSON.parse(text2);
        } catch {
          parsed = null;
        }
      }
      const { code, message } = normalizeError(parsed, response.status, response.statusText);
      throw new ApiError(code, message, { status: response.status });
    }
    const text = await response.text().catch(() => "");
    if (!text) return null;
    try {
      return JSON.parse(text);
    } catch (err) {
      throw new ApiError("BAD_RESPONSE", "response body was not valid JSON", { status: response.status, cause: err });
    }
  }
  function qs(params = {}) {
    const search = new URLSearchParams();
    for (const [key, value] of Object.entries(params)) {
      if (value === void 0 || value === null || value === "") continue;
      search.set(key, String(value));
    }
    const str = search.toString();
    return str ? `?${str}` : "";
  }
  function createApi({ baseUrl, token = null, fetchImpl, timeoutMs } = {}) {
    const call = (path, opts = {}) => apiRequest(path, { baseUrl, token, fetchImpl, timeoutMs, ...opts });
    return {
      health: () => call("/health"),
      authMe: () => call("/auth/me"),
      // Validate a GitHub PAT server-side; returns { api_token, github_login }.
      connectWithPat: (gitHubToken) => call("/auth/pat", { method: "POST", body: { token: gitHubToken } }),
      createSubmission: (submission) => call("/submissions", { method: "POST", body: submission }),
      listSubmissions: (params = {}) => call(`/submissions${qs(params)}`),
      createSync: (submissionId) => call("/sync", { method: "POST", body: { submission_id: submissionId } }),
      listSync: (params = {}) => call(`/sync${qs(params)}`),
      getSync: (id) => call(`/sync/${id}`),
      retrySync: (id) => call(`/sync/${id}/retry`, { method: "POST" }),
      getSettings: () => call("/settings"),
      updateSettings: (patch) => call("/settings", { method: "PATCH", body: patch }),
      getPlatforms: () => call("/platforms"),
      setPlatform: (id, enabled) => call(`/platforms/${encodeURIComponent(id)}`, { method: "PUT", body: { enabled } }),
      listRepos: (params = {}) => call(`/repos${qs(params)}`),
      createRepo: (payload) => call("/repos", { method: "POST", body: payload }),
      getStats: () => call("/stats"),
      deleteAccount: () => call("/account", { method: "DELETE" })
    };
  }

  // src/shared/auth.js
  var CHROMIUM_REDIRECT_RE = /^https:\/\/[a-z0-9]{32}\.chromiumapp\.org\/?$/i;
  function defaultRedirectUrl() {
    try {
      return chrome.identity?.getRedirectURL?.() || null;
    } catch {
      return null;
    }
  }
  function tokenFromAuthRedirect(url) {
    if (!url) return null;
    try {
      const token = new URL(url).searchParams.get("token");
      return typeof token === "string" && token.startsWith("cs_") ? token : null;
    } catch {
      return null;
    }
  }
  function buildAuthStartUrl(baseUrl, redirectUrl) {
    const base = String(baseUrl || "").replace(/\/+$/, "");
    return `${base}${API_PREFIX}/auth/github/start?client=extension&redirect_uri=${encodeURIComponent(
      redirectUrl
    )}`;
  }
  function defaultLaunch(url) {
    return new Promise((resolve, reject) => {
      chrome.identity.launchWebAuthFlow({ url, interactive: true }, (redirectedToUrl) => {
        const err = chrome.runtime && chrome.runtime.lastError;
        if (err) reject(new Error(err.message));
        else if (!redirectedToUrl) reject(new Error("sign-in was cancelled"));
        else resolve(redirectedToUrl);
      });
    });
  }
  async function connectWithGitHub(baseUrl, { launch, redirectUrl } = {}) {
    const launchFlow = launch || defaultLaunch;
    const redirect = redirectUrl || defaultRedirectUrl();
    if (!CHROMIUM_REDIRECT_RE.test(redirect || "")) {
      throw new Error("chrome.identity redirect URL is unavailable");
    }
    const redirectedTo = await launchFlow(buildAuthStartUrl(baseUrl, redirect));
    const token = tokenFromAuthRedirect(redirectedTo);
    if (!token) throw new Error("GitHub sign-in finished without an API token");
    return token;
  }

  // src/shared/sha256.js
  var K = new Uint32Array([
    1116352408,
    1899447441,
    3049323471,
    3921009573,
    961987163,
    1508970993,
    2453635748,
    2870763221,
    3624381080,
    310598401,
    607225278,
    1426881987,
    1925078388,
    2162078206,
    2614888103,
    3248222580,
    3835390401,
    4022224774,
    264347078,
    604807628,
    770255983,
    1249150122,
    1555081692,
    1996064986,
    2554220882,
    2821834349,
    2952996808,
    3210313671,
    3336571891,
    3584528711,
    113926993,
    338241895,
    666307205,
    773529912,
    1294757372,
    1396182291,
    1695183700,
    1986661051,
    2177026350,
    2456956037,
    2730485921,
    2820302411,
    3259730800,
    3345764771,
    3516065817,
    3600352804,
    4094571909,
    275423344,
    430227734,
    506948616,
    659060556,
    883997877,
    958139571,
    1322822218,
    1537002063,
    1747873779,
    1955562222,
    2024104815,
    2227730452,
    2361852424,
    2428436474,
    2756734187,
    3204031479,
    3329325298
  ]);
  function utf8Bytes(str) {
    const out = [];
    for (let i = 0; i < str.length; i += 1) {
      let cp = str.charCodeAt(i);
      if (cp < 128) {
        out.push(cp);
      } else if (cp < 2048) {
        out.push(192 | cp >> 6, 128 | cp & 63);
      } else if (cp >= 55296 && cp <= 56319 && i + 1 < str.length) {
        const next = str.charCodeAt(i + 1);
        if (next >= 56320 && next <= 57343) {
          cp = 65536 + (cp - 55296 << 10) + (next - 56320);
          i += 1;
          out.push(
            240 | cp >> 18,
            128 | cp >> 12 & 63,
            128 | cp >> 6 & 63,
            128 | cp & 63
          );
        } else {
          out.push(224 | cp >> 12, 128 | cp >> 6 & 63, 128 | cp & 63);
        }
      } else {
        out.push(224 | cp >> 12, 128 | cp >> 6 & 63, 128 | cp & 63);
      }
    }
    return Uint8Array.from(out);
  }
  function rotr(x, n) {
    return x >>> n | x << 32 - n;
  }
  function toHex(words) {
    let out = "";
    for (let i = 0; i < words.length; i += 1) {
      out += words[i].toString(16).padStart(8, "0");
    }
    return out;
  }
  function sha256(input) {
    const bytes = typeof input === "string" ? utf8Bytes(input) : Uint8Array.from(input);
    const bitLenHi = Math.floor(bytes.length / 536870912);
    const bitLenLo = bytes.length * 8 >>> 0;
    const paddedLen = Math.ceil((bytes.length + 9) / 64) * 64;
    const buf = new Uint8Array(paddedLen);
    buf.set(bytes);
    buf[bytes.length] = 128;
    const view = new DataView(buf.buffer);
    view.setUint32(paddedLen - 8, bitLenHi);
    view.setUint32(paddedLen - 4, bitLenLo);
    const h = new Uint32Array([
      1779033703,
      3144134277,
      1013904242,
      2773480762,
      1359893119,
      2600822924,
      528734635,
      1541459225
    ]);
    const w = new Uint32Array(64);
    for (let offset = 0; offset < paddedLen; offset += 64) {
      for (let i = 0; i < 16; i += 1) {
        w[i] = view.getUint32(offset + i * 4);
      }
      for (let i = 16; i < 64; i += 1) {
        const s0 = rotr(w[i - 15], 7) ^ rotr(w[i - 15], 18) ^ w[i - 15] >>> 3;
        const s1 = rotr(w[i - 2], 17) ^ rotr(w[i - 2], 19) ^ w[i - 2] >>> 10;
        w[i] = w[i - 16] + s0 + w[i - 7] + s1 >>> 0;
      }
      let a = h[0];
      let b = h[1];
      let c = h[2];
      let d = h[3];
      let e = h[4];
      let f = h[5];
      let g = h[6];
      let hh = h[7];
      for (let i = 0; i < 64; i += 1) {
        const S1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25);
        const ch = e & f ^ ~e & g;
        const temp1 = hh + S1 + ch + K[i] + w[i] >>> 0;
        const S0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22);
        const maj = a & b ^ a & c ^ b & c;
        const temp2 = S0 + maj >>> 0;
        hh = g;
        g = f;
        f = e;
        e = d + temp1 >>> 0;
        d = c;
        c = b;
        b = a;
        a = temp1 + temp2 >>> 0;
      }
      h[0] = h[0] + a >>> 0;
      h[1] = h[1] + b >>> 0;
      h[2] = h[2] + c >>> 0;
      h[3] = h[3] + d >>> 0;
      h[4] = h[4] + e >>> 0;
      h[5] = h[5] + f >>> 0;
      h[6] = h[6] + g >>> 0;
      h[7] = h[7] + hh >>> 0;
    }
    return toHex(h);
  }

  // src/shared/schema.js
  var SUBMISSION_FIELDS = [
    "platform",
    "title",
    "problem_id",
    "url",
    "language",
    "code",
    "external_id",
    "verdict",
    "submitted_at",
    "metadata",
    "fingerprint"
  ];
  var FINGERPRINT_RE = /^[0-9a-f]{64}$/;
  var ISO_RE = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d{1,6})?(Z|[+-]\d{2}:\d{2})$/;
  function isPlainObject(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value) && Object.getPrototypeOf(value) === Object.prototype;
  }
  function normalizeCode(code) {
    if (!code) return "";
    const text = String(code).replace(/\r\n/g, "\n").replace(/\r/g, "\n");
    const lines = text.split("\n").map((line) => line.replace(/[ \t]+$/g, ""));
    return lines.join("\n").trim();
  }
  function contentHash(code) {
    return sha256(normalizeCode(code));
  }
  function stableFingerprint(platform, external_id, url, language, code) {
    const plat = (platform || "").trim().toLowerCase();
    const ext = (external_id || "").trim();
    let basis;
    if (plat && ext) {
      basis = `id|${plat}|${ext}`;
    } else {
      basis = `content|${plat}|${(url || "").trim()}|${(language || "").trim().toLowerCase()}|${contentHash(code)}`;
    }
    return sha256(basis);
  }
  function checkType(errors, field, value, type, { nullable = false, min, max } = {}) {
    if (value === null || value === void 0) {
      if (nullable) return;
      errors.push(`${field} is required`);
      return;
    }
    if (typeof value !== type) {
      errors.push(`${field} must be a ${type}`);
      return;
    }
    if (min !== void 0 && value.length < min) errors.push(`${field} is too short`);
    if (max !== void 0 && value.length > max) errors.push(`${field} is too long`);
  }
  function validateSubmission(submission) {
    if (!isPlainObject(submission)) {
      return { ok: false, error: { code: "INVALID_SUBMISSION", message: "submission must be an object" } };
    }
    const keys = Object.keys(submission).sort();
    const expected = [...SUBMISSION_FIELDS].sort();
    if (keys.length !== expected.length || keys.some((k, i) => k !== expected[i])) {
      const missing = expected.filter((k) => !(k in submission));
      const extra = keys.filter((k) => !expected.includes(k));
      const parts = [];
      if (missing.length) parts.push(`missing: ${missing.join(", ")}`);
      if (extra.length) parts.push(`unexpected: ${extra.join(", ")}`);
      return {
        ok: false,
        error: { code: "INVALID_SUBMISSION", message: `submission fields mismatch (${parts.join("; ")})` }
      };
    }
    const errors = [];
    if (!PLATFORM_IDS.includes(submission.platform)) errors.push("platform is not supported");
    checkType(errors, "title", submission.title, "string", { min: 1, max: 500 });
    checkType(errors, "language", submission.language, "string", { min: 1, max: 64 });
    checkType(errors, "code", submission.code, "string", { nullable: true, max: 5e5 });
    checkType(errors, "problem_id", submission.problem_id, "string", { nullable: true, max: 120 });
    checkType(errors, "external_id", submission.external_id, "string", { nullable: true, max: 120 });
    checkType(errors, "url", submission.url, "string", { nullable: true, max: 1e3 });
    if (typeof submission.url === "string" && !/^https?:\/\//.test(submission.url)) {
      errors.push("url must be http(s)");
    }
    if (!VERDICTS.includes(submission.verdict)) errors.push("verdict is not allowed");
    if (submission.submitted_at !== null) {
      if (typeof submission.submitted_at !== "string" || !ISO_RE.test(submission.submitted_at) || Number.isNaN(Date.parse(submission.submitted_at))) {
        errors.push("submitted_at must be an ISO8601 string or null");
      }
    }
    if (submission.metadata !== null && !isPlainObject(submission.metadata)) {
      errors.push("metadata must be an object or null");
    }
    if (typeof submission.fingerprint !== "string" || !FINGERPRINT_RE.test(submission.fingerprint)) {
      errors.push("fingerprint must be a 64-char lowercase hex sha256");
    }
    if (errors.length) {
      return { ok: false, error: { code: "INVALID_SUBMISSION", message: errors[0] } };
    }
    return { ok: true };
  }
  function fail(code, message) {
    return { ok: false, error: { code, message } };
  }

  // src/shared/messaging.js
  function runtime() {
    return typeof chrome !== "undefined" && chrome.runtime ? chrome.runtime : null;
  }
  function sendRuntimeMessage(message) {
    const rt = runtime();
    if (!rt) return Promise.resolve(fail("NO_RUNTIME", "chrome.runtime is unavailable"));
    try {
      const result = rt.sendMessage(message);
      if (result && typeof result.then === "function") return result;
      return new Promise((resolve, reject) => {
        try {
          rt.sendMessage(message, (response) => {
            const err = rt.lastError;
            if (err) reject(new Error(err.message));
            else resolve(response);
          });
        } catch (err) {
          reject(err);
        }
      });
    } catch (err) {
      return Promise.resolve(fail("RUNTIME_ERROR", err && err.message ? err.message : "sendMessage failed"));
    }
  }
  async function request(type, payload = {}) {
    const response = await sendRuntimeMessage({ type, payload });
    if (!response || response.ok !== true) {
      const error = response && response.error || { code: "NO_RESPONSE", message: "no response from background" };
      const err = new Error(error.message || "request failed");
      err.code = error.code || "NO_RESPONSE";
      throw err;
    }
    return response;
  }

  // src/adapters/shared.js
  var LANG_TOKENS = [
    { re: /\btypescript\b/i, name: "TypeScript" },
    { re: /\bpython\s*(?:3|3\.\d+|\d+)\b/i, name: "Python3" },
    { re: /\bpython\d*\b/i, name: "Python" },
    { re: /\bpypy\s*\d*\b/i, name: "Python3" },
    { re: /\bjavascript\b/i, name: "JavaScript" },
    { re: /\bnode\.?js\b/i, name: "Node.js" },
    { re: /\bkotlin\b/i, name: "Kotlin" },
    { re: /\bswift\b/i, name: "Swift" },
    { re: /\brust\b/i, name: "Rust" },
    { re: /\bruby\b/i, name: "Ruby" },
    { re: /\bscala\b/i, name: "Scala" },
    { re: /\bdart\b/i, name: "Dart" },
    { re: /\belixir\b/i, name: "Elixir" },
    { re: /\berlang\b/i, name: "Erlang" },
    { re: /\bc\+\+/i, name: "C++" },
    { re: /\bcpp\b/i, name: "C++" },
    { re: /\bc#|\bcsharp\b/i, name: "C#" },
    { re: /\bgolang\b/i, name: "Go" },
    { re: /\bgo\b/i, name: "Go" },
    { re: /\bjava\b/i, name: "Java" },
    { re: /\bphp\b/i, name: "PHP" },
    { re: /\bbash\b|\bshell\b/i, name: "Bash" },
    { re: /\bmysql\b/i, name: "MySQL" },
    { re: /\bpostgres(?:ql)?\b/i, name: "PostgreSQL" },
    { re: /\bmssql\b|\bms sql\b|\bsql server\b/i, name: "MS SQL" },
    { re: /\boracle\b/i, name: "Oracle" },
    { re: /\bplain ?text\b/i, name: "Plain Text" },
    { re: /\br\b/i, name: "R" },
    { re: /\bc\b/i, name: "C" }
  ];
  var VERDICT_RULES = [
    {
      verdict: "rejected",
      re: /wrong answer|partially correct|time limit exceeded|memory limit exceeded|runtime error|compilation error|compile error|output limit exceeded|internal error|judging error|presentation error|accepted with warnings|segfault/i
    },
    {
      verdict: "accepted",
      // GFG: "Problem Solved Successfully"; CodeChef: "Correct"/"Correct Answer";
      // LeetCode: "Accepted". Bare "correct" is anchored to avoid prose matches.
      re: /correct answer|problem solved successfully|^\s*correct\s*$|\baccepted\b/im
    },
    {
      verdict: "pending",
      re: /pending|judging|in queue|\brunning\b|compiling|under evaluation|processing|queued/i
    }
  ];
  function queryAll(doc, selector) {
    if (!doc || !doc.querySelectorAll || !selector) return [];
    try {
      return Array.from(doc.querySelectorAll(selector));
    } catch {
      return [];
    }
  }
  function firstEl(doc, selectors) {
    for (const selector of Array.isArray(selectors) ? selectors : [selectors]) {
      const nodes = queryAll(doc, selector);
      if (nodes.length) return nodes[0];
    }
    return null;
  }
  function textOf(el) {
    if (!el) return "";
    const raw = el.textContent || "";
    return raw.replace(/\u00a0/g, " ").replace(/\s+/g, " ").trim();
  }
  function firstText(doc, selectors) {
    for (const selector of Array.isArray(selectors) ? selectors : [selectors]) {
      for (const el of queryAll(doc, selector)) {
        const text = textOf(el);
        if (text) return text;
      }
    }
    return null;
  }
  function findText(doc, selectors, re) {
    for (const selector of Array.isArray(selectors) ? selectors : [selectors]) {
      for (const el of queryAll(doc, selector)) {
        const text = textOf(el);
        if (text && (!re || re.test(text))) return text;
      }
    }
    return null;
  }
  function matchVerdict(text) {
    if (!text) return "unknown";
    for (const rule of VERDICT_RULES) {
      if (rule.re.test(text)) return rule.verdict;
    }
    return "unknown";
  }
  function extractStatus(doc, selectors) {
    const text = firstText(doc, selectors);
    if (!text) return "unknown";
    return matchVerdict(text);
  }
  function canonicalLanguage(raw) {
    if (!raw) return null;
    const text = String(raw);
    for (const token of LANG_TOKENS) {
      if (token.re.test(text)) return token.name;
    }
    return null;
  }
  function languageCandidates(el) {
    if (!el) return [];
    if (el.tagName === "SELECT") {
      const index = typeof el.selectedIndex === "number" ? el.selectedIndex : -1;
      const option = index >= 0 ? el.options?.[index] : el.querySelector("option[selected]");
      return [option && option.value, option && option.textContent, el.value].filter(Boolean);
    }
    const selected = el.querySelector && el.querySelector(
      '[aria-selected="true"],[aria-checked="true"],[data-selected="true"],.divider.text,.selected,[class*="selected"]'
    );
    return [
      el.getAttribute && el.getAttribute("value"),
      el.value,
      selected && textOf(selected),
      el.getAttribute && el.getAttribute("aria-label"),
      textOf(el)
    ].filter(Boolean);
  }
  function detectOnElement(el) {
    for (const candidate of languageCandidates(el)) {
      const canon = canonicalLanguage(candidate);
      if (canon) return canon;
    }
    return null;
  }
  function detectLanguage(doc, selectors = []) {
    for (const selector of selectors) {
      for (const el of queryAll(doc, selector)) {
        const canon = detectOnElement(el);
        if (canon) return canon;
      }
    }
    const bridged = getBridgeLang();
    if (bridged) return bridged;
    const generic = queryAll(
      doc,
      '[class*="lang"],[class*="Lang"],[id*="lang"],[id*="Lang"],[class*="pill"],[class*="dropdown"],select'
    );
    for (const el of generic) {
      const canon = detectOnElement(el);
      if (canon) return canon;
    }
    return null;
  }
  function cleanEditorText(text) {
    if (text === null || text === void 0) return null;
    const cleaned = String(text).replace(/[​‌‍﻿]/g, "");
    return cleaned.trim() ? cleaned : null;
  }
  var CODE_HINT_RE = /\b(?:def|class|function|return|import|from|public|private|static|void|const|let|var|for|while|if|else|elif|try|except|catch|throw|new|this|self|struct|enum|interface|package|using|namespace|template|printf|println|console|print|puts|fn|func|match|impl|end|do|then|function)\b|#include|int\s+main|System\.out|fmt\.|=>|->|::/;
  var TESTCASE_CONTAINER_RE = /test[-_ ]?case|custom[-_ ]?input|example[-_ ]?input|sample[-_ ]?input|console[-_ ]?input|result[-_ ]?input|input[-_ ]?editor/i;
  function inTestcaseContainer(el) {
    for (let node = el; node && node.nodeType === 1; node = node.parentElement) {
      const id = node.id || "";
      const cls = typeof node.className === "string" ? node.className : "";
      const aria = node.getAttribute && node.getAttribute("aria-label") || "";
      const dataCy = node.getAttribute && node.getAttribute("data-cy") || "";
      const locator = node.getAttribute && node.getAttribute("data-e2e-locator") || "";
      if (TESTCASE_CONTAINER_RE.test(`${id} ${cls} ${aria} ${dataCy} ${locator}`)) {
        return true;
      }
    }
    return false;
  }
  function looksLikeCode(text) {
    if (!text) return false;
    if (CODE_HINT_RE.test(text)) return true;
    const lines = text.split("\n");
    if (lines.length >= 3 && lines.filter((l) => /^[ \t]+\S/.test(l)).length >= 2) {
      return true;
    }
    return false;
  }
  function scoreCodeCandidate(text) {
    if (!text || !text.trim()) return -1;
    let score = 0;
    if (looksLikeCode(text)) score += 100;
    score += Math.min(String(text).length / 200, 20);
    if (/^[\[\]{}()0-9,\s.\-eE+:"']+$/.test(text.trim()) && !CODE_HINT_RE.test(text)) {
      score -= 50;
    }
    return score;
  }
  var bridgeText = { monaco: null, ace: null, monacoLang: null, aceLang: null, at: 0 };
  function getBridgeLang() {
    return canonicalLanguage(bridgeText.monacoLang) || canonicalLanguage(bridgeText.aceLang);
  }
  function editorText(el) {
    if (!el) return null;
    if (el.tagName === "TEXTAREA" || el.tagName === "INPUT") {
      return cleanEditorText(el.value);
    }
    const bridge = bridgeText;
    const classes = el.classList;
    if (classes && classes.contains("monaco-editor") && bridge.monaco) {
      return cleanEditorText(bridge.monaco);
    }
    if (bridge.ace && classes && (classes.contains("ace_editor") || el.querySelector && el.querySelector(".ace_content"))) {
      return cleanEditorText(bridge.ace);
    }
    const lines = queryAll(el, ".cm-line, .CodeMirror-line, .view-line, .ace_line");
    if (lines.length) {
      return cleanEditorText(lines.map((line) => line.textContent).join("\n"));
    }
    if (el.classList && el.classList.contains("cm-content")) {
      const cmLines = queryAll(el, ".cm-line");
      if (cmLines.length) return cleanEditorText(cmLines.map((line) => line.textContent).join("\n"));
    }
    return cleanEditorText(el.value !== void 0 && el.value !== "" ? el.value : el.textContent);
  }
  function extractCode(doc, selectors) {
    const list = Array.isArray(selectors) ? selectors : [selectors];
    let best = null;
    let bestScore = -1;
    for (const selector of list) {
      for (const el of queryAll(doc, selector)) {
        if (inTestcaseContainer(el)) continue;
        const text = editorText(el);
        if (!text) continue;
        const score = scoreCodeCandidate(text);
        if (score > bestScore) {
          best = text;
          bestScore = score;
        }
      }
    }
    if (best && bestScore > 0) return best;
    for (const selector of list) {
      for (const el of queryAll(doc, selector)) {
        if (inTestcaseContainer(el)) continue;
        const text = editorText(el);
        if (text) return text;
      }
    }
    return null;
  }
  function cleanTitle(raw, suffixes = []) {
    if (!raw) return null;
    let title = String(raw).replace(/\s+/g, " ").trim();
    for (const suffix of suffixes) {
      if (title.toLowerCase().endsWith(suffix.toLowerCase())) {
        title = title.slice(0, title.length - suffix.length).trim();
      }
    }
    title = title.replace(/\s*[|–—-]\s*$/, "").trim();
    return title || null;
  }
  function parseWhen(text, now = Date.now()) {
    if (!text) return null;
    const value = String(text).trim();
    if (/\d{4}-\d{2}-\d{2}/.test(value)) {
      const parsed = Date.parse(value);
      if (!Number.isNaN(parsed)) return parsed;
    }
    const relative = /(\d+)\s*(second|minute|hour|day|week|month)s?\s*ago/i.exec(value);
    if (relative) {
      const amount = Number(relative[1]);
      const units = {
        second: 1e3,
        minute: 6e4,
        hour: 36e5,
        day: 864e5,
        week: 6048e5,
        month: 2592e6
      };
      return now - amount * units[relative[2].toLowerCase()];
    }
    return null;
  }
  function attrText(doc, selectors, attr) {
    const el = firstEl(doc, selectors);
    if (!el) return null;
    const value = el.getAttribute(attr);
    return value && value.trim() ? value.trim() : null;
  }
  function slugFromUrl(url, pattern) {
    try {
      const parsed = new URL(url);
      const match = pattern.exec(parsed.pathname);
      return match ? match[1] : null;
    } catch {
      return null;
    }
  }
  function canonicalUrl(url) {
    if (!url) return null;
    try {
      const parsed = new URL(url);
      parsed.search = "";
      parsed.hash = "";
      return parsed.toString();
    } catch {
      return String(url);
    }
  }
  function detectSubmission(adapter, doc, url, now = Date.now()) {
    if (!adapter || !adapter.capabilities || !adapter.capabilities.submission_detection) return null;
    const metadata = adapter.extractProblemMetadata(doc, url);
    if (!metadata || !metadata.title) return null;
    const verdict = adapter.capabilities.verdict_extraction ? adapter.extractSubmissionStatus(doc) : "unknown";
    const code = adapter.capabilities.solution_code_extraction ? adapter.extractSolutionCode(doc) : null;
    const external_id = adapter.extractSubmissionId ? adapter.extractSubmissionId(doc, url) : null;
    const submitted_at = adapter.extractSubmittedAt ? adapter.extractSubmittedAt(doc, url, now) : null;
    const language = detectLanguage(doc, adapter.languageSelectors || []);
    const evidence = Boolean(code) || external_id !== null || verdict !== "unknown";
    if (!evidence) return null;
    return { metadata, verdict, code, language, external_id, submitted_at };
  }

  // src/shared/hostallow.js
  var PLATFORM_HOSTS = {
    leetcode: ["leetcode.com"],
    geeksforgeeks: ["geeksforgeeks.org"],
    codechef: ["codechef.com"],
    neetcode: ["neetcode.io"]
  };
  function hostsForPlatform(platformId) {
    return PLATFORM_HOSTS[platformId] || [];
  }

  // src/adapters/leetcode.js
  var HOSTS = hostsForPlatform("leetcode");
  var STATUS_SELECTORS = [
    '[data-e2e-locator="submission-status"]',
    ".submission-status",
    '[class*="verdict"]',
    '[class*="judge-result"]',
    ".submission-result",
    '#result-panel [class*="status"]'
  ];
  var CODE_SELECTORS = [
    ".cm-content",
    ".CodeMirror-code",
    ".monaco-editor",
    'textarea[name="code"]',
    "#codeEditor",
    ".editor textarea"
  ];
  var LANGUAGE_SELECTORS = [
    '[data-cy="lang-select"]',
    ".lang-select",
    'select[name="language"]',
    '[class*="lang-select"]',
    '[class*="language-select"]',
    // Live LeetCode UI: React-rendered control without legacy class names.
    '[data-e2e-locator*="lang" i]',
    "#lang-select",
    '[aria-label*="language" i]'
  ];
  var TITLE_SELECTORS = [
    '[data-cy="question-title"]',
    ".question-title",
    '[class*="question-title"]',
    'h1[data-cy="question-title"]'
  ];
  var leetcode = {
    id: "leetcode",
    hosts: HOSTS,
    capabilities: {
      submission_detection: true,
      verdict_extraction: true,
      solution_code_extraction: true,
      problem_metadata: true,
      manual_sync: true
    },
    languageSelectors: LANGUAGE_SELECTORS,
    canHandle(url) {
      try {
        const host = new URL(url).hostname.toLowerCase();
        return HOSTS.some((allowed) => host === allowed || host.endsWith(`.${allowed}`));
      } catch {
        return false;
      }
    },
    detectPage(url) {
      if (!leetcode.canHandle(url)) return false;
      let pathname = "";
      try {
        pathname = new URL(url).pathname;
      } catch {
        return false;
      }
      return /\/problems\/[^/]+/.test(pathname) || /\/submissions/.test(pathname);
    },
    extractProblemMetadata(doc, url) {
      const slug = slugFromUrl(url, /\/problems\/([^/]+)/);
      const rawTitle = firstText(doc, TITLE_SELECTORS) || cleanTitle(doc.title, [" - LeetCode", " - LeetCode.cn"]);
      const title = cleanTitle(rawTitle, [" - LeetCode"]);
      if (!title) return null;
      const numericId = attrText(doc, ["[data-question-id]"], "data-question-id");
      return {
        title,
        problem_id: slug || numericId || null,
        url: canonicalUrl(url),
        platform: "leetcode"
      };
    },
    extractSubmissionStatus(doc) {
      return extractStatus(doc, STATUS_SELECTORS);
    },
    extractSolutionCode(doc) {
      return extractCode(doc, CODE_SELECTORS);
    },
    extractSubmissionId(doc, url) {
      const fromUrl = slugFromUrl(url, /\/submissions\/(\d+)/);
      if (fromUrl) return fromUrl;
      const text = findText(
        doc,
        ['[data-e2e-locator="submission-id"]', "#submission-id", ".submission-id"],
        /submission id|#?\d{3,}/i
      );
      const match = text && /(\d{3,})/.exec(text);
      return match ? match[1] : null;
    },
    extractSubmittedAt(doc, url, now) {
      const iso = attrText(doc, ["time[datetime]", "[datetime]"], "datetime");
      if (iso) {
        const parsed = Date.parse(iso);
        if (!Number.isNaN(parsed)) return parsed;
      }
      const text = firstText(doc, [
        '[data-e2e-locator="submission-date"]',
        ".submission-time",
        ".submission-date",
        '[class*="submitted-time"]'
      ]);
      return parseWhen(text, now);
    },
    detect_submission(doc, url, now) {
      return detectSubmission(leetcode, doc, url, now);
    }
  };
  var leetcode_default = leetcode;

  // src/adapters/geeksforgeeks.js
  var HOSTS2 = hostsForPlatform("geeksforgeeks");
  var STATUS_SELECTORS2 = [
    ".gfg-result",
    "#submission-result",
    ".submission-result",
    ".result-row",
    '[class*="verdict"]',
    ".result"
  ];
  var CODE_SELECTORS2 = [
    // Live GFG problem pages render an ACE editor (#ace-editor), not CodeMirror.
    "#ace-editor",
    ".ace_editor:not(.ace_autocomplete)",
    ".ace_content",
    ".CodeMirror-code",
    ".cm-content",
    ".monaco-editor",
    "textarea#SolutionInput",
    'textarea[name="solution"]',
    ".editor textarea"
  ];
  var LANGUAGE_SELECTORS2 = [
    // Semantic-UI dropdown: selected value lives in .divider.text ("C (gcc 5.4)").
    '[class*="language_dropdown"] .divider.text',
    '[class*="language_dropdown"]',
    "select#language",
    "select#lang",
    "#language-select",
    'select[name="language"]',
    ".language-dropdown"
  ];
  var TITLE_SELECTORS2 = [
    ".problem-title",
    "h3.problem-title",
    '[itemprop="name"]',
    '[class*="problems_header_content"] h3',
    "h1"
  ];
  var geeksforgeeks = {
    id: "geeksforgeeks",
    hosts: HOSTS2,
    capabilities: {
      submission_detection: true,
      verdict_extraction: true,
      solution_code_extraction: true,
      problem_metadata: true,
      manual_sync: true
    },
    languageSelectors: LANGUAGE_SELECTORS2,
    canHandle(url) {
      try {
        const host = new URL(url).hostname.toLowerCase();
        return HOSTS2.some((allowed) => host === allowed || host.endsWith(`.${allowed}`));
      } catch {
        return false;
      }
    },
    detectPage(url) {
      if (!geeksforgeeks.canHandle(url)) return false;
      let pathname = "";
      try {
        pathname = new URL(url).pathname;
      } catch {
        return false;
      }
      return /\/problems\/[^/]+/.test(pathname) || /\/user\/[^/]+\/submissions/.test(pathname);
    },
    extractProblemMetadata(doc, url) {
      const slug = slugFromUrl(url, /\/problems\/([^/]+)/);
      const suffixes = [" | GeeksforGeeks", " - GeeksforGeeks", " | Practice"];
      const rawTitle = firstText(doc, TITLE_SELECTORS2) || cleanTitle(doc.title, suffixes);
      const title = cleanTitle(rawTitle, suffixes);
      if (!title) return null;
      const codeText = firstText(doc, [".problem-code", "#problemCode", '[class*="problem-code"]']);
      return {
        title,
        problem_id: codeText || slug || null,
        url: canonicalUrl(url),
        platform: "geeksforgeeks"
      };
    },
    extractSubmissionStatus(doc) {
      return extractStatus(doc, STATUS_SELECTORS2);
    },
    extractSolutionCode(doc) {
      return extractCode(doc, CODE_SELECTORS2);
    },
    extractSubmissionId() {
      return null;
    },
    extractSubmittedAt(doc, url, now) {
      const iso = attrText(doc, ["time[datetime]", "[datetime]"], "datetime");
      if (iso) {
        const parsed = Date.parse(iso);
        if (!Number.isNaN(parsed)) return parsed;
      }
      const text = firstText(doc, [".submission-time", ".timeago", '[class*="submitted"]', ".time"]);
      return parseWhen(text, now);
    },
    detect_submission(doc, url, now) {
      return detectSubmission(geeksforgeeks, doc, url, now);
    }
  };
  var geeksforgeeks_default = geeksforgeeks;

  // src/adapters/codechef.js
  var HOSTS3 = hostsForPlatform("codechef");
  var STATUS_SELECTORS3 = [
    ".cc-verdict",
    ".verdict",
    "#submission-result",
    ".submission-result",
    ".result-panel",
    ".result"
  ];
  var CODE_SELECTORS3 = [
    // Live CodeChef practice pages render an ACE editor (#submit-ide-v2).
    "#submit-ide-v2",
    ".ace_editor:not(.ace_autocomplete)",
    ".ace_content",
    ".CodeMirror-code",
    ".cm-content",
    ".monaco-editor",
    "textarea#solution",
    "textarea#editor",
    ".editor textarea"
  ];
  var LANGUAGE_SELECTORS3 = [
    "select#language",
    "#language-select",
    'select[name="language"]',
    ".language-dropdown",
    ".lang-dropdown"
  ];
  var TITLE_SELECTORS3 = [
    ".problem-title",
    '[class*="problem-title"]'
  ];
  var codechef = {
    id: "codechef",
    hosts: HOSTS3,
    capabilities: {
      submission_detection: true,
      verdict_extraction: true,
      solution_code_extraction: true,
      problem_metadata: true,
      manual_sync: true
    },
    languageSelectors: LANGUAGE_SELECTORS3,
    canHandle(url) {
      try {
        const host = new URL(url).hostname.toLowerCase();
        return HOSTS3.some((allowed) => host === allowed || host.endsWith(`.${allowed}`));
      } catch {
        return false;
      }
    },
    detectPage(url) {
      if (!codechef.canHandle(url)) return false;
      let pathname = "";
      try {
        pathname = new URL(url).pathname;
      } catch {
        return false;
      }
      return /\/problems\/[^/]+/.test(pathname) || /\/submissions\/[^/]+/.test(pathname) || /\/(?:viewsubmission|viewsolution)\/\d+/.test(pathname) || /\/practice\/problems\//.test(pathname) || /\/practice\/course\/[^/]+\/[^/]+\/problems\/[^/]+/.test(pathname);
    },
    extractProblemMetadata(doc, url) {
      const slug = slugFromUrl(url, /\/problems\/([^/]+)/);
      const suffixes = [" | CodeChef", " - CodeChef"];
      const stripMarker = (t) => t.replace(/\s+Practice Problem in\s+.+$/i, "").trim() || t;
      let title = "";
      const tagTitle = cleanTitle(doc.title, suffixes);
      if (tagTitle && /practice problem in\s+/i.test(tagTitle)) title = stripMarker(tagTitle);
      if (!title) {
        const fromElements = cleanTitle(firstText(doc, TITLE_SELECTORS3), suffixes);
        if (fromElements) title = stripMarker(fromElements);
      }
      if (!title && slug) title = slug;
      if (!title) return null;
      return {
        title,
        problem_id: slug || null,
        url: canonicalUrl(url),
        platform: "codechef"
      };
    },
    extractSubmissionStatus(doc) {
      return extractStatus(doc, STATUS_SELECTORS3);
    },
    extractSolutionCode(doc) {
      return extractCode(doc, CODE_SELECTORS3);
    },
    extractSubmissionId(doc, url) {
      const fromUrl = slugFromUrl(url, /\/(?:submissions|viewsubmission|viewsolution)\/([^/]+)/);
      if (fromUrl) return fromUrl;
      const text = findText(doc, ["#submission-id", ".submission-id", '[class*="submission-id"]'], /#?\d{3,}/);
      const match = text && /(\d{3,})/.exec(text);
      return match ? match[1] : null;
    },
    extractSubmittedAt(doc, url, now) {
      const iso = attrText(doc, ["time[datetime]", "[datetime]"], "datetime");
      if (iso) {
        const parsed = Date.parse(iso);
        if (!Number.isNaN(parsed)) return parsed;
      }
      const text = firstText(doc, [".submission-time", ".timeago", '[class*="submitted"]', ".time"]);
      return parseWhen(text, now);
    },
    detect_submission(doc, url, now) {
      return detectSubmission(codechef, doc, url, now);
    }
  };
  var codechef_default = codechef;

  // src/adapters/neetcode.js
  var HOSTS4 = hostsForPlatform("neetcode");
  var TITLE_SELECTORS4 = [
    ".problem-title",
    ".nc-problem-title",
    '[class*="problem-title"]',
    "h1",
    "h2"
  ];
  var neetcode = {
    id: "neetcode",
    hosts: HOSTS4,
    capabilities: {
      submission_detection: false,
      verdict_extraction: false,
      solution_code_extraction: false,
      problem_metadata: true,
      manual_sync: true
    },
    languageSelectors: [],
    canHandle(url) {
      try {
        const host = new URL(url).hostname.toLowerCase();
        return HOSTS4.some((allowed) => host === allowed || host.endsWith(`.${allowed}`));
      } catch {
        return false;
      }
    },
    detectPage(url, doc) {
      if (!neetcode.canHandle(url)) return false;
      let pathname = "";
      try {
        pathname = new URL(url).pathname;
      } catch {
        return false;
      }
      if (/\/(practice|roadmap|problems|problem)\b/.test(pathname)) return true;
      return Boolean(doc && neetcode.extractProblemMetadata(doc, url));
    },
    extractProblemMetadata(doc, url) {
      const slug = slugFromUrl(url, /\/problems\/([^/]+)/);
      const rawTitle = firstText(doc, TITLE_SELECTORS4) || cleanTitle(doc.title, [" - NeetCode"]);
      const title = cleanTitle(rawTitle, [" - NeetCode"]);
      if (!title) return null;
      if (/^neetcode$/i.test(title)) return null;
      return {
        title,
        problem_id: slug || null,
        url: canonicalUrl(url),
        platform: "neetcode"
      };
    },
    extractSubmissionStatus() {
      return "unknown";
    },
    extractSolutionCode() {
      return null;
    },
    extractSubmissionId() {
      return null;
    },
    extractSubmittedAt() {
      return null;
    },
    detect_submission() {
      return null;
    }
  };
  var neetcode_default = neetcode;

  // src/adapters/index.js
  var ADAPTERS = [leetcode_default, geeksforgeeks_default, codechef_default, neetcode_default];
  var ADAPTER_BY_ID = Object.fromEntries(ADAPTERS.map((adapter) => [adapter.id, adapter]));

  // src/options/options.js
  var $ = (id) => document.getElementById(id);
  var CAPABILITY_BADGES = [
    ["submission_detection", "auto-detect"],
    ["verdict_extraction", "verdicts"],
    ["solution_code_extraction", "code"],
    ["problem_metadata", "metadata"],
    ["submission_id", "submission id"],
    ["timestamp", "timestamp"]
  ];
  var localSettings = { apiBaseUrl: DEFAULT_API_BASE_URL, apiToken: "" };
  var remoteSettings = null;
  var api = null;
  var toastTimer = null;
  var pollTimer = null;
  function toast(message, isError = false) {
    const node = $("toast");
    node.textContent = message;
    node.classList.toggle("toast-error", isError);
    node.hidden = false;
    if (toastTimer) clearTimeout(toastTimer);
    toastTimer = setTimeout(() => {
      node.hidden = true;
    }, 3200);
  }
  function shortFingerprint(fingerprint) {
    return `${fingerprint.slice(0, 8)}\u2026${fingerprint.slice(-4)}`;
  }
  function setConnected(connected, githubLogin = null) {
    const chip = $("conn");
    chip.textContent = connected ? "connected" : "not connected";
    chip.classList.toggle("chip-ok", connected);
    chip.classList.toggle("chip-off", !connected);
    const link = $("repo-link");
    if (connected && githubLogin) {
      link.href = `https://github.com/${githubLogin}`;
      link.textContent = `@${githubLogin}`;
      link.hidden = false;
    } else if (!connected) {
      link.hidden = true;
    }
  }
  function isLocalOrigin(baseUrl) {
    try {
      const { hostname } = new URL(baseUrl);
      return hostname === "127.0.0.1" || hostname === "localhost" || hostname === "[::1]";
    } catch {
      return false;
    }
  }
  async function ensurePermission(baseUrl) {
    if (isLocalOrigin(baseUrl)) return true;
    let origin;
    try {
      origin = `${new URL(baseUrl).origin}/*`;
    } catch {
      return false;
    }
    if (typeof chrome === "undefined" || !chrome.permissions) return true;
    const descriptor = { origins: [origin] };
    try {
      if (await chrome.permissions.contains(descriptor)) return true;
      return await chrome.permissions.request(descriptor);
    } catch {
      return false;
    }
  }
  function apiFromSettings() {
    if (!localSettings.apiToken) return null;
    return createApi({ baseUrl: localSettings.apiBaseUrl, token: localSettings.apiToken });
  }
  function readForm() {
    return {
      apiBaseUrl: $("api-base-url").value.trim() || DEFAULT_API_BASE_URL,
      apiToken: $("api-token").value
    };
  }
  function fillForm() {
    $("api-base-url").value = localSettings.apiBaseUrl;
    $("api-token").value = localSettings.apiToken;
  }
  function renderRemoteSettings(settings) {
    remoteSettings = settings;
    if (!settings) {
      $("branch").value = "";
      $("root-folder").value = "";
      $("auto-sync").checked = true;
      return;
    }
    $("branch").value = settings.branch || "";
    $("root-folder").value = settings.root_folder || "";
    $("auto-sync").checked = settings.auto_sync !== false;
    const link = $("repo-link");
    if (settings.repo_full_name) {
      link.href = `https://github.com/${settings.repo_full_name}`;
      link.textContent = settings.repo_full_name;
      link.title = `Open ${settings.repo_full_name} on GitHub`;
      link.hidden = false;
      const select = $("repo-select");
      const existing = Array.from(select.options).find((o) => o.value === settings.repo_full_name);
      if (existing) select.value = settings.repo_full_name;
    }
  }
  async function loadLocal() {
    const response = await request("GET_SETTINGS");
    localSettings = response.settings;
    fillForm();
    api = apiFromSettings();
  }
  async function probeConnection() {
    if (!api) {
      setConnected(false);
      $("test-result").textContent = "No API token configured.";
      return;
    }
    try {
      const me = await api.authMe();
      setConnected(true, me.github_login || me.user && me.user.github_login || null);
      $("test-result").className = "hint hint-ok";
      $("test-result").textContent = `Authenticated${me.github_login ? ` as ${me.github_login}` : ""}.`;
    } catch {
      setConnected(false);
    }
  }
  async function loadRemoteSettings() {
    if (!api) {
      renderRemoteSettings(null);
      return;
    }
    try {
      const settings = await api.getSettings();
      renderRemoteSettings(settings);
    } catch (err) {
      renderRemoteSettings(null);
      if (err && err.code && err.code !== "NO_TOKEN") {
        toast(`Repository settings unavailable: ${err.message}`, true);
      }
    }
  }
  async function loadRepos() {
    const select = $("repo-select");
    select.replaceChildren();
    if (!api) {
      select.append(new Option("Configure an API token first", ""));
      return;
    }
    try {
      const response = await api.listRepos({ page: 1, per_page: 100 });
      const items = response && response.items || [];
      select.append(new Option("Select a repository\u2026", ""));
      for (const repo of items) {
        select.append(new Option(repo.full_name, repo.full_name));
      }
      if (remoteSettings && remoteSettings.repo_full_name) {
        select.value = remoteSettings.repo_full_name;
      }
      if (items.length === 0) toast("No repositories found for this account");
    } catch (err) {
      select.append(new Option("Failed to load repositories", ""));
      toast(`Repositories: ${err.message}`, true);
    }
  }
  async function createRepo() {
    const name = $("repo-name").value.trim();
    if (!name) {
      toast("Enter a repository name", true);
      return;
    }
    if (!api) {
      toast("Configure an API token first", true);
      return;
    }
    try {
      const repo = await api.createRepo({
        name,
        description: $("repo-desc").value.trim() || void 0,
        private: $("repo-private").checked
      });
      const select = $("repo-select");
      select.append(new Option(repo.full_name, repo.full_name));
      select.value = repo.full_name;
      toast(`Created ${repo.full_name}`);
      if (remoteSettings) {
        try {
          const updated = await api.updateSettings({ repo_full_name: repo.full_name });
          renderRemoteSettings(updated);
        } catch {
        }
      }
    } catch (err) {
      toast(`Create repo failed: ${err.message}`, true);
    }
  }
  function capabilityBadges(capabilities) {
    const wrap = document.createElement("div");
    wrap.className = "badges";
    if (!capabilities) {
      const badge = document.createElement("span");
      badge.className = "badge badge-muted";
      badge.textContent = "unknown";
      wrap.append(badge);
      return wrap;
    }
    let added = 0;
    for (const [key, label] of CAPABILITY_BADGES) {
      if (!capabilities[key]) continue;
      const badge = document.createElement("span");
      badge.className = "badge";
      badge.textContent = label;
      wrap.append(badge);
      added += 1;
    }
    if (added === 0) {
      const badge = document.createElement("span");
      badge.className = "badge badge-muted";
      badge.textContent = "metadata only";
      wrap.append(badge);
    }
    if (capabilities.requires_login) {
      const badge = document.createElement("span");
      badge.className = "badge badge-muted";
      badge.textContent = "login required";
      wrap.append(badge);
    }
    return wrap;
  }
  function localMatrix() {
    return ADAPTERS.map((adapter) => ({
      id: adapter.id,
      name: PLATFORM_LABELS[adapter.id] || adapter.id,
      enabled: true,
      capabilities: { ...adapter.capabilities },
      local: true
    }));
  }
  async function loadPlatforms() {
    let rows;
    let remote = true;
    if (api) {
      try {
        const response = await api.getPlatforms();
        rows = response && response.platforms || [];
      } catch {
        rows = localMatrix();
        remote = false;
      }
    } else {
      rows = localMatrix();
      remote = false;
    }
    renderPlatforms(rows, remote);
  }
  function renderPlatforms(rows, remote) {
    const container = $("platforms");
    container.replaceChildren();
    if (!rows.length) {
      container.append(Object.assign(document.createElement("p"), { className: "hint", textContent: "No platforms available." }));
      return;
    }
    if (!remote) {
      const hint = document.createElement("p");
      hint.className = "hint";
      hint.textContent = "Connect the API to enable or disable platforms. Showing the local capability matrix.";
      container.append(hint);
    }
    for (const row of rows) {
      const item = document.createElement("div");
      item.className = "platform-row";
      const info = document.createElement("div");
      info.className = "platform-info";
      const name = document.createElement("span");
      name.className = "platform-name";
      name.textContent = row.name || PLATFORM_LABELS[row.id] || row.id;
      info.append(name, capabilityBadges(row.capabilities));
      const label = document.createElement("label");
      label.className = "switch";
      const input = document.createElement("input");
      input.type = "checkbox";
      input.checked = row.enabled !== false;
      input.disabled = !remote;
      input.addEventListener("change", async () => {
        input.disabled = true;
        try {
          const response = await api.setPlatform(row.id, input.checked);
          const updated = (response.platforms || []).find((p) => p.id === row.id);
          renderPlatforms(
            (response.platforms || []).map((p) => ({
              ...p,
              enabled: updated ? updated.enabled : p.enabled
            })),
            true
          );
          await request("SET_SETTINGS", { apiBaseUrl: localSettings.apiBaseUrl }).catch(() => {
          });
          toast(`${name.textContent} ${input.checked ? "enabled" : "disabled"}`);
        } catch (err) {
          toast(err.message, true);
          input.disabled = false;
        }
      });
      const slider = document.createElement("span");
      slider.className = "slider";
      label.append(input, slider);
      item.append(info, label);
      container.append(item);
    }
  }
  function statTile(value, label, breakdown) {
    const tile = document.createElement("div");
    tile.className = "stat-tile";
    const val = document.createElement("span");
    val.className = "value";
    val.textContent = String(value);
    const lab = document.createElement("span");
    lab.className = "label";
    lab.textContent = label;
    tile.append(val, lab);
    if (breakdown) {
      const extra = document.createElement("div");
      extra.className = "stat-breakdown";
      extra.textContent = breakdown;
      tile.append(extra);
    }
    return tile;
  }
  function formatBreakdown(map) {
    if (!map) return "";
    const entries = Object.entries(map).filter(([, value]) => value > 0);
    if (!entries.length) return "";
    return entries.map(([key, value]) => `${key}: ${value}`).join(" \xB7 ");
  }
  async function loadStats() {
    const container = $("stats");
    if (!api) {
      container.replaceChildren();
      container.append(
        Object.assign(document.createElement("p"), {
          className: "hint",
          textContent: "Configure an API token to see sync statistics."
        })
      );
      return;
    }
    try {
      const stats = await api.getStats();
      container.replaceChildren(
        statTile(stats.submissions_total ?? 0, "submissions"),
        statTile(stats.accepted_total ?? 0, "accepted"),
        statTile(formatBreakdown(stats.jobs_by_state) || "\u2014", "jobs by state"),
        statTile(formatBreakdown(stats.submissions_by_platform) || "\u2014", "submissions by platform"),
        statTile(formatBreakdown(stats.synced_by_platform) || "\u2014", "synced by platform")
      );
    } catch {
      container.replaceChildren();
      container.append(
        Object.assign(document.createElement("p"), {
          className: "hint",
          textContent: "Stats unavailable until the API is reachable."
        })
      );
    }
  }
  function queueRow(item) {
    const li = document.createElement("li");
    const fp = document.createElement("span");
    fp.className = "fp";
    fp.textContent = shortFingerprint(item.fingerprint);
    const body = document.createElement("div");
    body.className = "body";
    const title = document.createElement("div");
    title.className = "title";
    title.textContent = `${item.title} \xB7 ${item.language || ""}`.trim();
    const meta = document.createElement("div");
    meta.className = "meta";
    if (item.last_error) {
      meta.textContent = `${item.last_error.code}: ${item.last_error.message}`;
    } else if (item.job_id != null) {
      meta.textContent = `job #${item.job_id} \xB7 attempt ${item.attempts}`;
    } else {
      meta.textContent = `${item.platform} \xB7 attempt ${item.attempts}`;
    }
    body.append(title, meta);
    const chip = document.createElement("span");
    chip.className = `state state-${item.state}`;
    chip.textContent = item.state === "done" ? "synced" : item.state;
    const cell = document.createElement("div");
    cell.className = "actions-cell";
    const retry = document.createElement("button");
    retry.className = "btn btn-sm";
    retry.type = "button";
    retry.textContent = "Retry";
    retry.disabled = item.state === "syncing" || item.state === "done";
    retry.addEventListener("click", async () => {
      retry.disabled = true;
      try {
        await request("RETRY_ITEM", { fingerprint: item.fingerprint });
        toast("Retry scheduled");
        await refreshQueue();
      } catch (err) {
        toast(err.message, true);
        retry.disabled = false;
      }
    });
    const remove = document.createElement("button");
    remove.className = "btn btn-sm btn-ghost";
    remove.type = "button";
    remove.textContent = "Remove";
    remove.addEventListener("click", async () => {
      try {
        await request("REMOVE_ITEM", { fingerprint: item.fingerprint });
        await refreshQueue();
      } catch (err) {
        toast(err.message, true);
      }
    });
    cell.append(retry, remove);
    li.append(fp, body, chip, cell);
    return li;
  }
  async function refreshQueue() {
    try {
      const state = await request("GET_STATE");
      setConnected(state.connected);
      const items = Array.isArray(state.queue) ? state.queue : [];
      const list = $("queue-list");
      list.replaceChildren(...items.map(queueRow));
      $("queue-empty").hidden = items.length > 0;
      const parts = [
        `${items.length} item${items.length === 1 ? "" : "s"}`,
        `${state.pending} pending`,
        `${state.failed} failed`
      ];
      if (state.paused) parts.push("paused");
      $("queue-summary").textContent = parts.join(" \xB7 ");
      if (state.lastError && state.lastError.code === "NO_TOKEN") {
        $("test-result").className = "hint hint-error";
        $("test-result").textContent = "No API token configured.";
      }
    } catch (err) {
      toast(err.message, true);
    }
  }
  async function saveSettings() {
    const form = readForm();
    if (!await ensurePermission(form.apiBaseUrl)) {
      toast("Host permission denied for that API origin", true);
      return;
    }
    try {
      const response = await request("SET_SETTINGS", form);
      localSettings = response.settings;
      api = apiFromSettings();
    } catch (err) {
      toast(err.message, true);
      return;
    }
    if (api) {
      const patch = { repo_full_name: $("repo-select").value || null, auto_sync: $("auto-sync").checked };
      const branch = $("branch").value.trim();
      const root = $("root-folder").value.trim();
      if (branch) patch.branch = branch;
      if (root) patch.root_folder = root;
      try {
        const updated = await api.updateSettings(patch);
        renderRemoteSettings(updated);
      } catch (err) {
        toast(`Repository settings: ${err.message}`, true);
        return;
      }
    }
    toast("Settings saved");
    await probeConnection();
    await loadPlatforms();
  }
  async function finishConnect(baseUrl, token, label) {
    if (!await ensurePermission(baseUrl)) {
      toast("Host permission denied for that API origin", true);
      return;
    }
    const response = await request("SET_SETTINGS", { apiBaseUrl: baseUrl, apiToken: token });
    localSettings = response.settings;
    api = apiFromSettings();
    $("api-token").value = token;
    toast(label);
    await probeConnection();
    await loadRemoteSettings();
    await loadRepos();
    await loadPlatforms();
    await loadStats();
    await refreshQueue();
  }
  async function oauthSignIn() {
    const baseUrl = $("api-base-url").value.trim() || DEFAULT_API_BASE_URL;
    $("test-result").className = "hint";
    $("test-result").textContent = "Waiting for GitHub\u2026";
    try {
      const token = await connectWithGitHub(baseUrl);
      await finishConnect(baseUrl, token, "Signed in with GitHub");
      $("test-result").className = "hint hint-ok";
      $("test-result").textContent = "Signed in \u2014 token stored automatically.";
    } catch (err) {
      setConnected(false);
      $("test-result").className = "hint hint-error";
      $("test-result").textContent = `GitHub sign-in failed: ${err.message}. If the backend has no OAuth app, use the PAT option below.`;
      $("pat-details").open = true;
    }
  }
  async function patSignIn() {
    const baseUrl = $("api-base-url").value.trim() || DEFAULT_API_BASE_URL;
    const pat = $("github-pat").value.trim();
    if (!pat) {
      toast("Enter a GitHub personal access token first", true);
      return;
    }
    if (!await ensurePermission(baseUrl)) {
      toast("Host permission denied for that API origin", true);
      return;
    }
    try {
      const out = await createApi({ baseUrl }).connectWithPat(pat);
      $("github-pat").value = "";
      await finishConnect(baseUrl, out.api_token, `Connected as ${out.github_login}`);
    } catch (err) {
      toast(`Connect failed: ${err.code ? `${err.code}: ` : ""}${err.message}`, true);
    }
  }
  async function testConnection() {
    const form = readForm();
    $("test-result").className = "hint";
    $("test-result").textContent = "Testing\u2026";
    if (!await ensurePermission(form.apiBaseUrl)) {
      $("test-result").className = "hint hint-error";
      $("test-result").textContent = "Host permission denied for that API origin.";
      return;
    }
    try {
      const settingsResponse = await request("SET_SETTINGS", form);
      localSettings = settingsResponse.settings;
      api = apiFromSettings();
      const result = await request("TEST_CONNECTION");
      setConnected(true, result.github_login || null);
      $("test-result").className = "hint hint-ok";
      $("test-result").textContent = `Connected${result.github_login ? ` as ${result.github_login}` : ""}.`;
      await loadRepos();
      await loadPlatforms();
      await loadStats();
      await loadRemoteSettings();
    } catch (err) {
      setConnected(false);
      $("test-result").className = "hint hint-error";
      $("test-result").textContent = `${err.code || "ERROR"}: ${err.message}`;
    }
  }
  async function submitManual() {
    const platform = $("manual-platform").value;
    const title = $("manual-title").value.trim();
    const language = $("manual-language").value.trim();
    const url = $("manual-url").value.trim() || null;
    const code = $("manual-code").value;
    if (!title || !language || !code.trim()) {
      toast("Title, language and code are required", true);
      return;
    }
    const submission = {
      platform,
      title,
      problem_id: null,
      url,
      language,
      code,
      external_id: null,
      verdict: "manual",
      submitted_at: (/* @__PURE__ */ new Date()).toISOString(),
      metadata: null,
      fingerprint: stableFingerprint(platform, null, url, language, code)
    };
    const validation = validateSubmission(submission);
    if (!validation.ok) {
      toast(validation.error.message, true);
      return;
    }
    try {
      const result = await request("SUBMIT_MANUAL", submission);
      toast(result.deduped ? "Already queued" : "Manual submission queued");
      $("manual-code").value = "";
      await refreshQueue();
    } catch (err) {
      toast(err.message, true);
    }
  }
  async function deleteAccount() {
    const confirmed = window.confirm(
      "Delete the CodeSync account and ALL stored submissions, sync jobs and settings? This cannot be undone."
    );
    if (!confirmed) return;
    if (!api) {
      toast("Configure an API token first", true);
      return;
    }
    try {
      await api.deleteAccount();
      await request("SET_SETTINGS", { apiBaseUrl: localSettings.apiBaseUrl, apiToken: "" });
      localSettings.apiToken = "";
      api = null;
      remoteSettings = null;
      renderRemoteSettings(null);
      setConnected(false);
      $("test-result").className = "hint";
      $("test-result").textContent = "Account deleted.";
      toast("Account deleted");
      await loadRepos();
      await loadPlatforms();
      await loadStats();
      await refreshQueue();
    } catch (err) {
      toast(`Delete failed: ${err.message}`, true);
    }
  }
  async function clearQueue() {
    try {
      await request("CLEAR_QUEUE");
      toast("Queue cleared");
      await refreshQueue();
    } catch (err) {
      toast(err.message, true);
    }
  }
  function bind() {
    $("btn-save").addEventListener("click", () => {
      saveSettings().catch((err) => toast(err.message, true));
    });
    $("btn-oauth").addEventListener("click", () => {
      oauthSignIn().catch((err) => toast(err.message, true));
    });
    $("btn-pat").addEventListener("click", () => {
      patSignIn().catch((err) => toast(err.message, true));
    });
    $("btn-test").addEventListener("click", () => {
      testConnection().catch((err) => toast(err.message, true));
    });
    $("btn-reload-repos").addEventListener("click", () => {
      loadRepos().catch((err) => toast(err.message, true));
    });
    $("btn-create-repo").addEventListener("click", () => {
      createRepo().catch((err) => toast(err.message, true));
    });
    $("btn-manual").addEventListener("click", () => {
      submitManual().catch((err) => toast(err.message, true));
    });
    $("btn-delete").addEventListener("click", () => {
      deleteAccount().catch((err) => toast(err.message, true));
    });
    $("btn-clear-queue").addEventListener("click", () => {
      clearQueue().catch((err) => toast(err.message, true));
    });
  }
  async function init() {
    const platformSelect = $("manual-platform");
    for (const id of PLATFORM_IDS) {
      platformSelect.append(new Option(PLATFORM_LABELS[id] || id, id));
    }
    bind();
    try {
      await loadLocal();
      await probeConnection();
      await loadRemoteSettings();
      await loadRepos();
      await loadPlatforms();
      await loadStats();
      await refreshQueue();
    } catch (err) {
      toast(err.message, true);
    }
    pollTimer = setInterval(() => {
      refreshQueue().catch(() => {
      });
      loadStats().catch(() => {
      });
    }, 5e3);
    window.addEventListener("unload", () => {
      if (pollTimer) clearInterval(pollTimer);
    });
  }
  init();
})();
