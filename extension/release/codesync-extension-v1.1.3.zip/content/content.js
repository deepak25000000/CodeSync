(() => {
  // src/shared/config.js
  var PLATFORM_IDS = ["leetcode", "geeksforgeeks", "codechef", "neetcode"];
  var VERDICTS = ["accepted", "rejected", "pending", "manual", "unknown"];

  // src/shared/sha256.js
  var K = new Uint32Array([
    1116352408,
    1899447441,
    3049323471,
    3921009573,
    961987163,
    1508970993,
    2453635748,
    2870763221,
    3624381080,
    310598401,
    607225278,
    1426881987,
    1925078388,
    2162078206,
    2614888103,
    3248222580,
    3835390401,
    4022224774,
    264347078,
    604807628,
    770255983,
    1249150122,
    1555081692,
    1996064986,
    2554220882,
    2821834349,
    2952996808,
    3210313671,
    3336571891,
    3584528711,
    113926993,
    338241895,
    666307205,
    773529912,
    1294757372,
    1396182291,
    1695183700,
    1986661051,
    2177026350,
    2456956037,
    2730485921,
    2820302411,
    3259730800,
    3345764771,
    3516065817,
    3600352804,
    4094571909,
    275423344,
    430227734,
    506948616,
    659060556,
    883997877,
    958139571,
    1322822218,
    1537002063,
    1747873779,
    1955562222,
    2024104815,
    2227730452,
    2361852424,
    2428436474,
    2756734187,
    3204031479,
    3329325298
  ]);
  function utf8Bytes(str) {
    const out = [];
    for (let i = 0; i < str.length; i += 1) {
      let cp = str.charCodeAt(i);
      if (cp < 128) {
        out.push(cp);
      } else if (cp < 2048) {
        out.push(192 | cp >> 6, 128 | cp & 63);
      } else if (cp >= 55296 && cp <= 56319 && i + 1 < str.length) {
        const next = str.charCodeAt(i + 1);
        if (next >= 56320 && next <= 57343) {
          cp = 65536 + (cp - 55296 << 10) + (next - 56320);
          i += 1;
          out.push(
            240 | cp >> 18,
            128 | cp >> 12 & 63,
            128 | cp >> 6 & 63,
            128 | cp & 63
          );
        } else {
          out.push(224 | cp >> 12, 128 | cp >> 6 & 63, 128 | cp & 63);
        }
      } else {
        out.push(224 | cp >> 12, 128 | cp >> 6 & 63, 128 | cp & 63);
      }
    }
    return Uint8Array.from(out);
  }
  function rotr(x, n) {
    return x >>> n | x << 32 - n;
  }
  function toHex(words) {
    let out = "";
    for (let i = 0; i < words.length; i += 1) {
      out += words[i].toString(16).padStart(8, "0");
    }
    return out;
  }
  function sha256(input) {
    const bytes = typeof input === "string" ? utf8Bytes(input) : Uint8Array.from(input);
    const bitLenHi = Math.floor(bytes.length / 536870912);
    const bitLenLo = bytes.length * 8 >>> 0;
    const paddedLen = Math.ceil((bytes.length + 9) / 64) * 64;
    const buf = new Uint8Array(paddedLen);
    buf.set(bytes);
    buf[bytes.length] = 128;
    const view = new DataView(buf.buffer);
    view.setUint32(paddedLen - 8, bitLenHi);
    view.setUint32(paddedLen - 4, bitLenLo);
    const h = new Uint32Array([
      1779033703,
      3144134277,
      1013904242,
      2773480762,
      1359893119,
      2600822924,
      528734635,
      1541459225
    ]);
    const w = new Uint32Array(64);
    for (let offset = 0; offset < paddedLen; offset += 64) {
      for (let i = 0; i < 16; i += 1) {
        w[i] = view.getUint32(offset + i * 4);
      }
      for (let i = 16; i < 64; i += 1) {
        const s0 = rotr(w[i - 15], 7) ^ rotr(w[i - 15], 18) ^ w[i - 15] >>> 3;
        const s1 = rotr(w[i - 2], 17) ^ rotr(w[i - 2], 19) ^ w[i - 2] >>> 10;
        w[i] = w[i - 16] + s0 + w[i - 7] + s1 >>> 0;
      }
      let a = h[0];
      let b = h[1];
      let c = h[2];
      let d = h[3];
      let e = h[4];
      let f = h[5];
      let g = h[6];
      let hh = h[7];
      for (let i = 0; i < 64; i += 1) {
        const S1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25);
        const ch = e & f ^ ~e & g;
        const temp1 = hh + S1 + ch + K[i] + w[i] >>> 0;
        const S0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22);
        const maj = a & b ^ a & c ^ b & c;
        const temp2 = S0 + maj >>> 0;
        hh = g;
        g = f;
        f = e;
        e = d + temp1 >>> 0;
        d = c;
        c = b;
        b = a;
        a = temp1 + temp2 >>> 0;
      }
      h[0] = h[0] + a >>> 0;
      h[1] = h[1] + b >>> 0;
      h[2] = h[2] + c >>> 0;
      h[3] = h[3] + d >>> 0;
      h[4] = h[4] + e >>> 0;
      h[5] = h[5] + f >>> 0;
      h[6] = h[6] + g >>> 0;
      h[7] = h[7] + hh >>> 0;
    }
    return toHex(h);
  }

  // src/shared/schema.js
  var SUBMISSION_FIELDS = [
    "platform",
    "title",
    "problem_id",
    "url",
    "language",
    "code",
    "external_id",
    "verdict",
    "submitted_at",
    "metadata",
    "fingerprint"
  ];
  var FINGERPRINT_RE = /^[0-9a-f]{64}$/;
  var ISO_RE = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d{1,6})?(Z|[+-]\d{2}:\d{2})$/;
  function isPlainObject(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value) && Object.getPrototypeOf(value) === Object.prototype;
  }
  function normalizeCode(code) {
    if (!code) return "";
    const text = String(code).replace(/\r\n/g, "\n").replace(/\r/g, "\n");
    const lines = text.split("\n").map((line) => line.replace(/[ \t]+$/g, ""));
    return lines.join("\n").trim();
  }
  function contentHash(code) {
    return sha256(normalizeCode(code));
  }
  function stableFingerprint(platform, external_id, url, language, code) {
    const plat = (platform || "").trim().toLowerCase();
    const ext = (external_id || "").trim();
    let basis;
    if (plat && ext) {
      basis = `id|${plat}|${ext}`;
    } else {
      basis = `content|${plat}|${(url || "").trim()}|${(language || "").trim().toLowerCase()}|${contentHash(code)}`;
    }
    return sha256(basis);
  }
  function checkType(errors, field, value, type, { nullable = false, min, max } = {}) {
    if (value === null || value === void 0) {
      if (nullable) return;
      errors.push(`${field} is required`);
      return;
    }
    if (typeof value !== type) {
      errors.push(`${field} must be a ${type}`);
      return;
    }
    if (min !== void 0 && value.length < min) errors.push(`${field} is too short`);
    if (max !== void 0 && value.length > max) errors.push(`${field} is too long`);
  }
  function validateSubmission(submission) {
    if (!isPlainObject(submission)) {
      return { ok: false, error: { code: "INVALID_SUBMISSION", message: "submission must be an object" } };
    }
    const keys = Object.keys(submission).sort();
    const expected = [...SUBMISSION_FIELDS].sort();
    if (keys.length !== expected.length || keys.some((k, i) => k !== expected[i])) {
      const missing = expected.filter((k) => !(k in submission));
      const extra = keys.filter((k) => !expected.includes(k));
      const parts = [];
      if (missing.length) parts.push(`missing: ${missing.join(", ")}`);
      if (extra.length) parts.push(`unexpected: ${extra.join(", ")}`);
      return {
        ok: false,
        error: { code: "INVALID_SUBMISSION", message: `submission fields mismatch (${parts.join("; ")})` }
      };
    }
    const errors = [];
    if (!PLATFORM_IDS.includes(submission.platform)) errors.push("platform is not supported");
    checkType(errors, "title", submission.title, "string", { min: 1, max: 500 });
    checkType(errors, "language", submission.language, "string", { min: 1, max: 64 });
    checkType(errors, "code", submission.code, "string", { nullable: true, max: 5e5 });
    checkType(errors, "problem_id", submission.problem_id, "string", { nullable: true, max: 120 });
    checkType(errors, "external_id", submission.external_id, "string", { nullable: true, max: 120 });
    checkType(errors, "url", submission.url, "string", { nullable: true, max: 1e3 });
    if (typeof submission.url === "string" && !/^https?:\/\//.test(submission.url)) {
      errors.push("url must be http(s)");
    }
    if (!VERDICTS.includes(submission.verdict)) errors.push("verdict is not allowed");
    if (submission.submitted_at !== null) {
      if (typeof submission.submitted_at !== "string" || !ISO_RE.test(submission.submitted_at) || Number.isNaN(Date.parse(submission.submitted_at))) {
        errors.push("submitted_at must be an ISO8601 string or null");
      }
    }
    if (submission.metadata !== null && !isPlainObject(submission.metadata)) {
      errors.push("metadata must be an object or null");
    }
    if (typeof submission.fingerprint !== "string" || !FINGERPRINT_RE.test(submission.fingerprint)) {
      errors.push("fingerprint must be a 64-char lowercase hex sha256");
    }
    if (errors.length) {
      return { ok: false, error: { code: "INVALID_SUBMISSION", message: errors[0] } };
    }
    return { ok: true };
  }
  function emptyPayload(payload) {
    if (!isPlainObject(payload)) return "payload must be an object";
    if (Object.keys(payload).length !== 0) return "payload must be an empty object";
    return null;
  }
  var CONTENT_MESSAGE_SPECS = {
    SYNC_PAGE: { validate: emptyPayload }
  };
  function validateAgainst(specs, message) {
    if (!isPlainObject(message)) {
      return { ok: false, error: { code: "INVALID_MESSAGE", message: "message must be an object" } };
    }
    const keys = Object.keys(message).sort();
    if (keys.length !== 2 || keys[0] !== "payload" || keys[1] !== "type") {
      return {
        ok: false,
        error: { code: "INVALID_MESSAGE", message: "message must be exactly {type, payload}" }
      };
    }
    const spec = specs[message.type];
    if (!spec) {
      return { ok: false, error: { code: "UNKNOWN_MESSAGE", message: `unknown message type: ${message.type}` } };
    }
    const payloadError = spec.validate(message.payload);
    if (payloadError) {
      return { ok: false, error: { code: "INVALID_PAYLOAD", message: payloadError } };
    }
    return { ok: true, type: message.type, payload: message.payload };
  }
  function validateContentMessage(message) {
    return validateAgainst(CONTENT_MESSAGE_SPECS, message);
  }
  function ok(data = {}) {
    return { ok: true, ...data };
  }
  function fail(code, message) {
    return { ok: false, error: { code, message } };
  }

  // src/adapters/shared.js
  var LANG_TOKENS = [
    { re: /\btypescript\b/i, name: "TypeScript" },
    { re: /\bpython\s*(?:3|3\.\d+|\d+)\b/i, name: "Python3" },
    { re: /\bpython\d*\b/i, name: "Python" },
    { re: /\bpypy\s*\d*\b/i, name: "Python3" },
    { re: /\bjavascript\b/i, name: "JavaScript" },
    { re: /\bnode\.?js\b/i, name: "Node.js" },
    { re: /\bkotlin\b/i, name: "Kotlin" },
    { re: /\bswift\b/i, name: "Swift" },
    { re: /\brust\b/i, name: "Rust" },
    { re: /\bruby\b/i, name: "Ruby" },
    { re: /\bscala\b/i, name: "Scala" },
    { re: /\bdart\b/i, name: "Dart" },
    { re: /\belixir\b/i, name: "Elixir" },
    { re: /\berlang\b/i, name: "Erlang" },
    { re: /\bc\+\+/i, name: "C++" },
    { re: /\bcpp\b/i, name: "C++" },
    { re: /\bc#|\bcsharp\b/i, name: "C#" },
    { re: /\bgolang\b/i, name: "Go" },
    { re: /\bgo\b/i, name: "Go" },
    { re: /\bjava\b/i, name: "Java" },
    { re: /\bphp\b/i, name: "PHP" },
    { re: /\bbash\b|\bshell\b/i, name: "Bash" },
    { re: /\bmysql\b/i, name: "MySQL" },
    { re: /\bpostgres(?:ql)?\b/i, name: "PostgreSQL" },
    { re: /\bmssql\b|\bms sql\b|\bsql server\b/i, name: "MS SQL" },
    { re: /\boracle\b/i, name: "Oracle" },
    { re: /\bplain ?text\b/i, name: "Plain Text" },
    { re: /\br\b/i, name: "R" },
    { re: /\bc\b/i, name: "C" }
  ];
  var VERDICT_RULES = [
    {
      verdict: "rejected",
      re: /wrong answer|partially correct|time limit exceeded|memory limit exceeded|runtime error|compilation error|compile error|output limit exceeded|internal error|judging error|presentation error|accepted with warnings|segfault/i
    },
    {
      verdict: "accepted",
      // GFG: "Problem Solved Successfully"; CodeChef: "Correct"/"Correct Answer";
      // LeetCode: "Accepted". Bare "correct" is anchored to avoid prose matches.
      re: /correct answer|problem solved successfully|^\s*correct\s*$|\baccepted\b/im
    },
    {
      verdict: "pending",
      re: /pending|judging|in queue|\brunning\b|compiling|under evaluation|processing|queued/i
    }
  ];
  function queryAll(doc, selector) {
    if (!doc || !doc.querySelectorAll || !selector) return [];
    try {
      return Array.from(doc.querySelectorAll(selector));
    } catch {
      return [];
    }
  }
  function firstEl(doc, selectors) {
    for (const selector of Array.isArray(selectors) ? selectors : [selectors]) {
      const nodes = queryAll(doc, selector);
      if (nodes.length) return nodes[0];
    }
    return null;
  }
  function textOf(el) {
    if (!el) return "";
    const raw = el.textContent || "";
    return raw.replace(/\u00a0/g, " ").replace(/\s+/g, " ").trim();
  }
  function firstText(doc, selectors) {
    for (const selector of Array.isArray(selectors) ? selectors : [selectors]) {
      for (const el of queryAll(doc, selector)) {
        const text = textOf(el);
        if (text) return text;
      }
    }
    return null;
  }
  function findText(doc, selectors, re) {
    for (const selector of Array.isArray(selectors) ? selectors : [selectors]) {
      for (const el of queryAll(doc, selector)) {
        const text = textOf(el);
        if (text && (!re || re.test(text))) return text;
      }
    }
    return null;
  }
  function matchVerdict(text) {
    if (!text) return "unknown";
    for (const rule of VERDICT_RULES) {
      if (rule.re.test(text)) return rule.verdict;
    }
    return "unknown";
  }
  function extractStatus(doc, selectors) {
    const text = firstText(doc, selectors);
    if (!text) return "unknown";
    return matchVerdict(text);
  }
  function canonicalLanguage(raw) {
    if (!raw) return null;
    const text = String(raw);
    for (const token of LANG_TOKENS) {
      if (token.re.test(text)) return token.name;
    }
    return null;
  }
  function languageCandidates(el) {
    if (!el) return [];
    if (el.tagName === "SELECT") {
      const index = typeof el.selectedIndex === "number" ? el.selectedIndex : -1;
      const option = index >= 0 ? el.options?.[index] : el.querySelector("option[selected]");
      return [option && option.value, option && option.textContent, el.value].filter(Boolean);
    }
    const selected = el.querySelector && el.querySelector(
      '[aria-selected="true"],[aria-checked="true"],[data-selected="true"],.divider.text,.selected,[class*="selected"]'
    );
    return [
      el.getAttribute && el.getAttribute("value"),
      el.value,
      selected && textOf(selected),
      el.getAttribute && el.getAttribute("aria-label"),
      textOf(el)
    ].filter(Boolean);
  }
  function detectOnElement(el) {
    for (const candidate of languageCandidates(el)) {
      const canon = canonicalLanguage(candidate);
      if (canon) return canon;
    }
    return null;
  }
  function detectLanguage(doc, selectors = []) {
    for (const selector of selectors) {
      for (const el of queryAll(doc, selector)) {
        const canon = detectOnElement(el);
        if (canon) return canon;
      }
    }
    const bridged = getBridgeLang();
    if (bridged) return bridged;
    const generic = queryAll(
      doc,
      '[class*="lang"],[class*="Lang"],[id*="lang"],[id*="Lang"],[class*="pill"],[class*="dropdown"],select'
    );
    for (const el of generic) {
      const canon = detectOnElement(el);
      if (canon) return canon;
    }
    return null;
  }
  var SNIFF_RULES = [
    ["PHP", /<\?php\b/],
    [
      "Python3",
      /(?:^|\n)[ \t]*(?:def\s+\w+\s*\([^)]*\)\s*(?:->[^\n]*)?:|class\s+\w+\s*:(?=\n|$)|from\s+[\w.]+\s+import\s+\w|import\s+(?:numpy|sys|collections|math|typing|re|heapq|itertools|functools)\b)/
    ],
    ["Java", /\bSystem\.out\.print|\bpublic\s+(?:static|class)\b|\bnew\s+(?:ArrayList|HashMap|StringBuilder)</],
    [
      "C++",
      /\busing\s+namespace\s+std\s*;|\bstd::|#include\s*<(?:vector|string|iostream|map|algorithm|set|queue|stack|unordered_map)>/
    ],
    ["C#", /\busing\s+System\s*;|Console\.WriteLine/],
    ["C", /#include\s*<stdio\.h>|\b(?:int|void)\s+main\s*\(|\bprintf\s*\(/],
    ["Go", /\bfmt\.(?:Print|Sprintf)|\bpackage\s+main\b/],
    ["Rust", /\bfn\s+main\s*\(|println!|\blet\s+mut\s+/],
    ["Kotlin", /(?:^|\n)[ \t]*fun\s+\w+/],
    ["Swift", /\bfunc\s+\w+\s*\(|import\s+Foundation/],
    ["TypeScript", /interface\s+\w+\s*\{|:\s*(?:string|number|boolean)\s*[;)=,]/],
    ["JavaScript", /console\.log\s*\(|=>|\b(?:const|let)\s+\w+\s*=|\bclass\s+\w+\s*\{/],
    ["Ruby", /(?:^|\n)[ \t]*(?:puts\s|require\s+['"])/],
    ["Elixir", /\bdefmodule\s+\w+\s+do\b|\bdefp\s+\w+/],
    ["Erlang", /-module\(|-export\(/],
    ["Scala", /\bobject\s+\w+\s+extends\b/],
    ["Dart", /import\s+['"]package:/],
    ["Bash", /#!\s*\/bin\/(?:ba)?sh|(?:^|\n)[ \t]*echo\s/],
    ["MySQL", /(?:^|\n)[ \t]*(?:select\b[\s\S]*?\bfrom\b|insert\s+into\b|create\s+table\b)/i]
  ];
  function sniffLanguage(code) {
    if (typeof code !== "string" || !code.trim()) return null;
    for (const [name, re] of SNIFF_RULES) {
      if (re.test(code)) return name;
    }
    return null;
  }
  function cleanEditorText(text) {
    if (text === null || text === void 0) return null;
    const cleaned = String(text).replace(/[​‌‍﻿]/g, "");
    return cleaned.trim() ? cleaned : null;
  }
  var CODE_HINT_RE = /\b(?:def|class|function|return|import|from|public|private|static|void|const|let|var|for|while|if|else|elif|try|except|catch|throw|new|this|self|struct|enum|interface|package|using|namespace|template|printf|println|console|print|puts|fn|func|match|impl|end|do|then|function)\b|#include|int\s+main|System\.out|fmt\.|=>|->|::/;
  var TESTCASE_CONTAINER_RE = /test[-_ ]?case|custom[-_ ]?input|example[-_ ]?input|sample[-_ ]?input|console[-_ ]?input|result[-_ ]?input|input[-_ ]?editor/i;
  function inTestcaseContainer(el) {
    for (let node = el; node && node.nodeType === 1; node = node.parentElement) {
      const id = node.id || "";
      const cls = typeof node.className === "string" ? node.className : "";
      const aria = node.getAttribute && node.getAttribute("aria-label") || "";
      const dataCy = node.getAttribute && node.getAttribute("data-cy") || "";
      const locator = node.getAttribute && node.getAttribute("data-e2e-locator") || "";
      if (TESTCASE_CONTAINER_RE.test(`${id} ${cls} ${aria} ${dataCy} ${locator}`)) {
        return true;
      }
    }
    return false;
  }
  function looksLikeCode(text) {
    if (!text) return false;
    if (CODE_HINT_RE.test(text)) return true;
    const lines = text.split("\n");
    if (lines.length >= 3 && lines.filter((l) => /^[ \t]+\S/.test(l)).length >= 2) {
      return true;
    }
    return false;
  }
  function scoreCodeCandidate(text) {
    if (!text || !text.trim()) return -1;
    let score = 0;
    if (looksLikeCode(text)) score += 100;
    score += Math.min(String(text).length / 200, 20);
    if (/^[\[\]{}()0-9,\s.\-eE+:"']+$/.test(text.trim()) && !CODE_HINT_RE.test(text)) {
      score -= 50;
    }
    return score;
  }
  var bridgeText = { monaco: null, ace: null, monacoLang: null, aceLang: null, at: 0 };
  function langOrNull(value) {
    return typeof value === "string" && value.trim() ? value.trim() : null;
  }
  function setBridgeText(next) {
    bridgeText = {
      monaco: next && next.monaco ? String(next.monaco) : null,
      ace: next && next.ace ? String(next.ace) : null,
      // Raw editor language ids ("python3", "ace/mode/python" basename …) —
      // canonicalised on read by getBridgeLang().
      monacoLang: langOrNull(next && next.monacoLang),
      aceLang: langOrNull(next && next.aceLang),
      at: next && next.at || Date.now()
    };
  }
  function getBridgeLang() {
    return canonicalLanguage(bridgeText.monacoLang) || canonicalLanguage(bridgeText.aceLang);
  }
  function editorText(el) {
    if (!el) return null;
    if (el.tagName === "TEXTAREA" || el.tagName === "INPUT") {
      return cleanEditorText(el.value);
    }
    const bridge = bridgeText;
    const classes = el.classList;
    if (classes && classes.contains("monaco-editor") && bridge.monaco) {
      return cleanEditorText(bridge.monaco);
    }
    if (bridge.ace && classes && (classes.contains("ace_editor") || el.querySelector && el.querySelector(".ace_content"))) {
      return cleanEditorText(bridge.ace);
    }
    const lines = queryAll(el, ".cm-line, .CodeMirror-line, .view-line, .ace_line");
    if (lines.length) {
      return cleanEditorText(lines.map((line) => line.textContent).join("\n"));
    }
    if (el.classList && el.classList.contains("cm-content")) {
      const cmLines = queryAll(el, ".cm-line");
      if (cmLines.length) return cleanEditorText(cmLines.map((line) => line.textContent).join("\n"));
    }
    return cleanEditorText(el.value !== void 0 && el.value !== "" ? el.value : el.textContent);
  }
  function extractCode(doc, selectors) {
    const list = Array.isArray(selectors) ? selectors : [selectors];
    let best = null;
    let bestScore = -1;
    for (const selector of list) {
      for (const el of queryAll(doc, selector)) {
        if (inTestcaseContainer(el)) continue;
        const text = editorText(el);
        if (!text) continue;
        const score = scoreCodeCandidate(text);
        if (score > bestScore) {
          best = text;
          bestScore = score;
        }
      }
    }
    if (best && bestScore > 0) return best;
    for (const selector of list) {
      for (const el of queryAll(doc, selector)) {
        if (inTestcaseContainer(el)) continue;
        const text = editorText(el);
        if (text) return text;
      }
    }
    return null;
  }
  function cleanTitle(raw, suffixes = []) {
    if (!raw) return null;
    let title = String(raw).replace(/\s+/g, " ").trim();
    for (const suffix of suffixes) {
      if (title.toLowerCase().endsWith(suffix.toLowerCase())) {
        title = title.slice(0, title.length - suffix.length).trim();
      }
    }
    title = title.replace(/\s*[|–—-]\s*$/, "").trim();
    return title || null;
  }
  function parseWhen(text, now = Date.now()) {
    if (!text) return null;
    const value = String(text).trim();
    if (/\d{4}-\d{2}-\d{2}/.test(value)) {
      const parsed = Date.parse(value);
      if (!Number.isNaN(parsed)) return parsed;
    }
    const relative = /(\d+)\s*(second|minute|hour|day|week|month)s?\s*ago/i.exec(value);
    if (relative) {
      const amount = Number(relative[1]);
      const units = {
        second: 1e3,
        minute: 6e4,
        hour: 36e5,
        day: 864e5,
        week: 6048e5,
        month: 2592e6
      };
      return now - amount * units[relative[2].toLowerCase()];
    }
    return null;
  }
  function attrText(doc, selectors, attr) {
    const el = firstEl(doc, selectors);
    if (!el) return null;
    const value = el.getAttribute(attr);
    return value && value.trim() ? value.trim() : null;
  }
  function slugFromUrl(url, pattern) {
    try {
      const parsed = new URL(url);
      const match = pattern.exec(parsed.pathname);
      return match ? match[1] : null;
    } catch {
      return null;
    }
  }
  function canonicalUrl(url) {
    if (!url) return null;
    try {
      const parsed = new URL(url);
      parsed.search = "";
      parsed.hash = "";
      return parsed.toString();
    } catch {
      return String(url);
    }
  }
  function detectSubmission(adapter, doc, url, now = Date.now()) {
    if (!adapter || !adapter.capabilities || !adapter.capabilities.submission_detection) return null;
    const metadata = adapter.extractProblemMetadata(doc, url);
    if (!metadata || !metadata.title) return null;
    const verdict = adapter.capabilities.verdict_extraction ? adapter.extractSubmissionStatus(doc) : "unknown";
    const code = adapter.capabilities.solution_code_extraction ? adapter.extractSolutionCode(doc) : null;
    const external_id = adapter.extractSubmissionId ? adapter.extractSubmissionId(doc, url) : null;
    const submitted_at = adapter.extractSubmittedAt ? adapter.extractSubmittedAt(doc, url, now) : null;
    const language = detectLanguage(doc, adapter.languageSelectors || []);
    const evidence = Boolean(code) || external_id !== null || verdict !== "unknown";
    if (!evidence) return null;
    return { metadata, verdict, code, language, external_id, submitted_at };
  }

  // src/shared/hostallow.js
  var PLATFORM_HOSTS = {
    leetcode: ["leetcode.com"],
    geeksforgeeks: ["geeksforgeeks.org"],
    codechef: ["codechef.com"],
    neetcode: ["neetcode.io"]
  };
  function hostsForPlatform(platformId) {
    return PLATFORM_HOSTS[platformId] || [];
  }
  function allowedHostnames() {
    return PLATFORM_IDS.flatMap((id) => hostsForPlatform(id));
  }
  function isAllowedHostname(hostname) {
    if (!hostname) return false;
    const host = String(hostname).toLowerCase().replace(/\.$/, "");
    return allowedHostnames().some((allowed) => host === allowed || host.endsWith(`.${allowed}`));
  }
  function isAllowedUrl(url) {
    try {
      return isAllowedHostname(new URL(url).hostname);
    } catch {
      return false;
    }
  }

  // src/adapters/leetcode.js
  var HOSTS = hostsForPlatform("leetcode");
  var STATUS_SELECTORS = [
    '[data-e2e-locator="submission-status"]',
    ".submission-status",
    '[class*="verdict"]',
    '[class*="judge-result"]',
    ".submission-result",
    '#result-panel [class*="status"]'
  ];
  var CODE_SELECTORS = [
    ".cm-content",
    ".CodeMirror-code",
    ".monaco-editor",
    'textarea[name="code"]',
    "#codeEditor",
    ".editor textarea"
  ];
  var LANGUAGE_SELECTORS = [
    '[data-cy="lang-select"]',
    ".lang-select",
    'select[name="language"]',
    '[class*="lang-select"]',
    '[class*="language-select"]',
    // Live LeetCode UI: React-rendered control without legacy class names.
    '[data-e2e-locator*="lang" i]',
    "#lang-select",
    '[aria-label*="language" i]'
  ];
  var TITLE_SELECTORS = [
    '[data-cy="question-title"]',
    ".question-title",
    '[class*="question-title"]',
    'h1[data-cy="question-title"]'
  ];
  var leetcode = {
    id: "leetcode",
    hosts: HOSTS,
    capabilities: {
      submission_detection: true,
      verdict_extraction: true,
      solution_code_extraction: true,
      problem_metadata: true,
      manual_sync: true
    },
    languageSelectors: LANGUAGE_SELECTORS,
    canHandle(url) {
      try {
        const host = new URL(url).hostname.toLowerCase();
        return HOSTS.some((allowed) => host === allowed || host.endsWith(`.${allowed}`));
      } catch {
        return false;
      }
    },
    detectPage(url) {
      if (!leetcode.canHandle(url)) return false;
      let pathname = "";
      try {
        pathname = new URL(url).pathname;
      } catch {
        return false;
      }
      return /\/problems\/[^/]+/.test(pathname) || /\/submissions/.test(pathname);
    },
    extractProblemMetadata(doc, url) {
      const slug = slugFromUrl(url, /\/problems\/([^/]+)/);
      const rawTitle = firstText(doc, TITLE_SELECTORS) || cleanTitle(doc.title, [" - LeetCode", " - LeetCode.cn"]);
      const title = cleanTitle(rawTitle, [" - LeetCode"]);
      if (!title) return null;
      const numericId = attrText(doc, ["[data-question-id]"], "data-question-id");
      return {
        title,
        problem_id: slug || numericId || null,
        url: canonicalUrl(url),
        platform: "leetcode"
      };
    },
    extractSubmissionStatus(doc) {
      return extractStatus(doc, STATUS_SELECTORS);
    },
    extractSolutionCode(doc) {
      return extractCode(doc, CODE_SELECTORS);
    },
    extractSubmissionId(doc, url) {
      const fromUrl = slugFromUrl(url, /\/submissions\/(\d+)/);
      if (fromUrl) return fromUrl;
      const text = findText(
        doc,
        ['[data-e2e-locator="submission-id"]', "#submission-id", ".submission-id"],
        /submission id|#?\d{3,}/i
      );
      const match = text && /(\d{3,})/.exec(text);
      return match ? match[1] : null;
    },
    extractSubmittedAt(doc, url, now) {
      const iso = attrText(doc, ["time[datetime]", "[datetime]"], "datetime");
      if (iso) {
        const parsed = Date.parse(iso);
        if (!Number.isNaN(parsed)) return parsed;
      }
      const text = firstText(doc, [
        '[data-e2e-locator="submission-date"]',
        ".submission-time",
        ".submission-date",
        '[class*="submitted-time"]'
      ]);
      return parseWhen(text, now);
    },
    detect_submission(doc, url, now) {
      return detectSubmission(leetcode, doc, url, now);
    }
  };
  var leetcode_default = leetcode;

  // src/adapters/geeksforgeeks.js
  var HOSTS2 = hostsForPlatform("geeksforgeeks");
  var STATUS_SELECTORS2 = [
    ".gfg-result",
    "#submission-result",
    ".submission-result",
    ".result-row",
    '[class*="verdict"]',
    ".result"
  ];
  var CODE_SELECTORS2 = [
    // Live GFG problem pages render an ACE editor (#ace-editor), not CodeMirror.
    "#ace-editor",
    ".ace_editor:not(.ace_autocomplete)",
    ".ace_content",
    ".CodeMirror-code",
    ".cm-content",
    ".monaco-editor",
    "textarea#SolutionInput",
    'textarea[name="solution"]',
    ".editor textarea"
  ];
  var LANGUAGE_SELECTORS2 = [
    // Semantic-UI dropdown: selected value lives in .divider.text ("C (gcc 5.4)").
    '[class*="language_dropdown"] .divider.text',
    '[class*="language_dropdown"]',
    "select#language",
    "select#lang",
    "#language-select",
    'select[name="language"]',
    ".language-dropdown"
  ];
  var TITLE_SELECTORS2 = [
    ".problem-title",
    "h3.problem-title",
    '[itemprop="name"]',
    '[class*="problems_header_content"] h3',
    "h1"
  ];
  var geeksforgeeks = {
    id: "geeksforgeeks",
    hosts: HOSTS2,
    capabilities: {
      submission_detection: true,
      verdict_extraction: true,
      solution_code_extraction: true,
      problem_metadata: true,
      manual_sync: true
    },
    languageSelectors: LANGUAGE_SELECTORS2,
    canHandle(url) {
      try {
        const host = new URL(url).hostname.toLowerCase();
        return HOSTS2.some((allowed) => host === allowed || host.endsWith(`.${allowed}`));
      } catch {
        return false;
      }
    },
    detectPage(url) {
      if (!geeksforgeeks.canHandle(url)) return false;
      let pathname = "";
      try {
        pathname = new URL(url).pathname;
      } catch {
        return false;
      }
      return /\/problems\/[^/]+/.test(pathname) || /\/user\/[^/]+\/submissions/.test(pathname);
    },
    extractProblemMetadata(doc, url) {
      const slug = slugFromUrl(url, /\/problems\/([^/]+)/);
      const suffixes = [" | GeeksforGeeks", " - GeeksforGeeks", " | Practice"];
      const rawTitle = firstText(doc, TITLE_SELECTORS2) || cleanTitle(doc.title, suffixes);
      const title = cleanTitle(rawTitle, suffixes);
      if (!title) return null;
      const codeText = firstText(doc, [".problem-code", "#problemCode", '[class*="problem-code"]']);
      return {
        title,
        problem_id: codeText || slug || null,
        url: canonicalUrl(url),
        platform: "geeksforgeeks"
      };
    },
    extractSubmissionStatus(doc) {
      return extractStatus(doc, STATUS_SELECTORS2);
    },
    extractSolutionCode(doc) {
      return extractCode(doc, CODE_SELECTORS2);
    },
    extractSubmissionId() {
      return null;
    },
    extractSubmittedAt(doc, url, now) {
      const iso = attrText(doc, ["time[datetime]", "[datetime]"], "datetime");
      if (iso) {
        const parsed = Date.parse(iso);
        if (!Number.isNaN(parsed)) return parsed;
      }
      const text = firstText(doc, [".submission-time", ".timeago", '[class*="submitted"]', ".time"]);
      return parseWhen(text, now);
    },
    detect_submission(doc, url, now) {
      return detectSubmission(geeksforgeeks, doc, url, now);
    }
  };
  var geeksforgeeks_default = geeksforgeeks;

  // src/adapters/codechef.js
  var HOSTS3 = hostsForPlatform("codechef");
  var STATUS_SELECTORS3 = [
    ".cc-verdict",
    ".verdict",
    "#submission-result",
    ".submission-result",
    ".result-panel",
    ".result"
  ];
  var CODE_SELECTORS3 = [
    // Live CodeChef practice pages render an ACE editor (#submit-ide-v2).
    "#submit-ide-v2",
    ".ace_editor:not(.ace_autocomplete)",
    ".ace_content",
    ".CodeMirror-code",
    ".cm-content",
    ".monaco-editor",
    "textarea#solution",
    "textarea#editor",
    ".editor textarea"
  ];
  var LANGUAGE_SELECTORS3 = [
    "select#language",
    "#language-select",
    'select[name="language"]',
    ".language-dropdown",
    ".lang-dropdown"
  ];
  var TITLE_SELECTORS3 = [
    ".problem-title",
    '[class*="problem-title"]'
  ];
  var codechef = {
    id: "codechef",
    hosts: HOSTS3,
    capabilities: {
      submission_detection: true,
      verdict_extraction: true,
      solution_code_extraction: true,
      problem_metadata: true,
      manual_sync: true
    },
    languageSelectors: LANGUAGE_SELECTORS3,
    canHandle(url) {
      try {
        const host = new URL(url).hostname.toLowerCase();
        return HOSTS3.some((allowed) => host === allowed || host.endsWith(`.${allowed}`));
      } catch {
        return false;
      }
    },
    detectPage(url) {
      if (!codechef.canHandle(url)) return false;
      let pathname = "";
      try {
        pathname = new URL(url).pathname;
      } catch {
        return false;
      }
      return /\/problems\/[^/]+/.test(pathname) || /\/submissions\/[^/]+/.test(pathname) || /\/(?:viewsubmission|viewsolution)\/\d+/.test(pathname) || /\/practice\/problems\//.test(pathname) || /\/practice\/course\/[^/]+\/[^/]+\/problems\/[^/]+/.test(pathname);
    },
    extractProblemMetadata(doc, url) {
      const slug = slugFromUrl(url, /\/problems\/([^/]+)/);
      const suffixes = [" | CodeChef", " - CodeChef"];
      const stripMarker = (t) => t.replace(/\s+Practice Problem in\s+.+$/i, "").trim() || t;
      let title = "";
      const tagTitle = cleanTitle(doc.title, suffixes);
      if (tagTitle && /practice problem in\s+/i.test(tagTitle)) title = stripMarker(tagTitle);
      if (!title) {
        const fromElements = cleanTitle(firstText(doc, TITLE_SELECTORS3), suffixes);
        if (fromElements) title = stripMarker(fromElements);
      }
      if (!title && slug) title = slug;
      if (!title) return null;
      return {
        title,
        problem_id: slug || null,
        url: canonicalUrl(url),
        platform: "codechef"
      };
    },
    extractSubmissionStatus(doc) {
      return extractStatus(doc, STATUS_SELECTORS3);
    },
    extractSolutionCode(doc) {
      return extractCode(doc, CODE_SELECTORS3);
    },
    extractSubmissionId(doc, url) {
      const fromUrl = slugFromUrl(url, /\/(?:submissions|viewsubmission|viewsolution)\/([^/]+)/);
      if (fromUrl) return fromUrl;
      const text = findText(doc, ["#submission-id", ".submission-id", '[class*="submission-id"]'], /#?\d{3,}/);
      const match = text && /(\d{3,})/.exec(text);
      return match ? match[1] : null;
    },
    extractSubmittedAt(doc, url, now) {
      const iso = attrText(doc, ["time[datetime]", "[datetime]"], "datetime");
      if (iso) {
        const parsed = Date.parse(iso);
        if (!Number.isNaN(parsed)) return parsed;
      }
      const text = firstText(doc, [".submission-time", ".timeago", '[class*="submitted"]', ".time"]);
      return parseWhen(text, now);
    },
    detect_submission(doc, url, now) {
      return detectSubmission(codechef, doc, url, now);
    }
  };
  var codechef_default = codechef;

  // src/adapters/neetcode.js
  var HOSTS4 = hostsForPlatform("neetcode");
  var TITLE_SELECTORS4 = [
    ".problem-title",
    ".nc-problem-title",
    '[class*="problem-title"]',
    "h1",
    "h2"
  ];
  var neetcode = {
    id: "neetcode",
    hosts: HOSTS4,
    capabilities: {
      submission_detection: false,
      verdict_extraction: false,
      solution_code_extraction: false,
      problem_metadata: true,
      manual_sync: true
    },
    languageSelectors: [],
    canHandle(url) {
      try {
        const host = new URL(url).hostname.toLowerCase();
        return HOSTS4.some((allowed) => host === allowed || host.endsWith(`.${allowed}`));
      } catch {
        return false;
      }
    },
    detectPage(url, doc) {
      if (!neetcode.canHandle(url)) return false;
      let pathname = "";
      try {
        pathname = new URL(url).pathname;
      } catch {
        return false;
      }
      if (/\/(practice|roadmap|problems|problem)\b/.test(pathname)) return true;
      return Boolean(doc && neetcode.extractProblemMetadata(doc, url));
    },
    extractProblemMetadata(doc, url) {
      const slug = slugFromUrl(url, /\/problems\/([^/]+)/);
      const rawTitle = firstText(doc, TITLE_SELECTORS4) || cleanTitle(doc.title, [" - NeetCode"]);
      const title = cleanTitle(rawTitle, [" - NeetCode"]);
      if (!title) return null;
      if (/^neetcode$/i.test(title)) return null;
      return {
        title,
        problem_id: slug || null,
        url: canonicalUrl(url),
        platform: "neetcode"
      };
    },
    extractSubmissionStatus() {
      return "unknown";
    },
    extractSolutionCode() {
      return null;
    },
    extractSubmissionId() {
      return null;
    },
    extractSubmittedAt() {
      return null;
    },
    detect_submission() {
      return null;
    }
  };
  var neetcode_default = neetcode;

  // src/adapters/index.js
  var ADAPTERS = [leetcode_default, geeksforgeeks_default, codechef_default, neetcode_default];
  var ADAPTER_BY_ID = Object.fromEntries(ADAPTERS.map((adapter) => [adapter.id, adapter]));
  function matchHost(url) {
    if (!url) return null;
    for (const adapter of ADAPTERS) {
      if (adapter.canHandle(url)) return adapter;
    }
    return null;
  }
  function toIso(value) {
    if (value === null || value === void 0 || value === "") return null;
    const parsed = typeof value === "number" ? value : Date.parse(value);
    if (Number.isNaN(parsed)) return null;
    return new Date(parsed).toISOString();
  }
  function nullableString(value, max) {
    if (typeof value !== "string") return null;
    const trimmed = value.trim();
    if (!trimmed) return null;
    return trimmed.slice(0, max);
  }
  function normalize_submission(adapter, raw) {
    if (!adapter || !raw || typeof raw !== "object") return null;
    const meta = raw.metadata && typeof raw.metadata === "object" ? raw.metadata : null;
    if (!meta) return null;
    const title = typeof meta.title === "string" ? meta.title.trim() : "";
    if (!title) return null;
    const platform = adapter.id;
    const url = typeof meta.url === "string" && meta.url ? meta.url : null;
    const detected = typeof raw.language === "string" && raw.language.trim() ? raw.language.trim() : "";
    const language = (detected && detected !== "unknown" ? detected : null) || sniffLanguage(raw.code) || "unknown";
    const code = typeof raw.code === "string" ? raw.code : null;
    const verdict = VERDICTS.includes(raw.verdict) ? raw.verdict : "unknown";
    const external_id = nullableString(raw.external_id, 120);
    const problem_id = nullableString(meta.problem_id, 120);
    const { title: _title, problem_id: _problemId, url: _url, platform: _platform, ...extras } = meta;
    const submission = {
      platform,
      title,
      problem_id,
      url,
      language,
      code,
      external_id,
      verdict,
      submitted_at: toIso(raw.submitted_at),
      metadata: Object.keys(extras).length ? extras : null,
      fingerprint: stableFingerprint(platform, external_id, url, language, code)
    };
    const validation = validateSubmission(submission);
    return validation.ok ? submission : null;
  }
  function buildManualSubmission(adapter, doc, url, { now = Date.now(), code = null, language = null } = {}) {
    if (!adapter || !adapter.capabilities.manual_sync) return null;
    const metadata = adapter.extractProblemMetadata(doc, url);
    if (!metadata) return null;
    const editorCode = code || (adapter.capabilities.solution_code_extraction && adapter.extractSolutionCode ? adapter.extractSolutionCode(doc) : null);
    return normalize_submission(adapter, {
      metadata,
      verdict: "manual",
      code: editorCode,
      // null (not 'unknown') so normalize_submission can still sniff the
      // language from the code before giving up.
      language: language || detectLanguage(doc, adapter.languageSelectors || []),
      external_id: null,
      submitted_at: now
    });
  }

  // src/shared/messaging.js
  function runtime() {
    return typeof chrome !== "undefined" && chrome.runtime ? chrome.runtime : null;
  }
  function sendRuntimeMessage(message) {
    const rt = runtime();
    if (!rt) return Promise.resolve(fail("NO_RUNTIME", "chrome.runtime is unavailable"));
    try {
      const result = rt.sendMessage(message);
      if (result && typeof result.then === "function") return result;
      return new Promise((resolve, reject) => {
        try {
          rt.sendMessage(message, (response) => {
            const err = rt.lastError;
            if (err) reject(new Error(err.message));
            else resolve(response);
          });
        } catch (err) {
          reject(err);
        }
      });
    } catch (err) {
      return Promise.resolve(fail("RUNTIME_ERROR", err && err.message ? err.message : "sendMessage failed"));
    }
  }

  // src/content/bridge.js
  var SOURCE = "codesync-bridge";
  var seq = 0;
  var pending = /* @__PURE__ */ new Map();
  window.addEventListener("message", (event) => {
    if (event.source !== window) return;
    const data = event.data;
    if (!data || data.source !== SOURCE) return;
    if (data.type === "ready") {
      requestBridge().then(() => {
      });
      return;
    }
    if (data.type === "response") {
      const done = pending.get(data.id);
      if (done) {
        setBridgeText({
          monaco: data.monaco,
          ace: data.ace,
          monacoLang: data.monacoLang,
          aceLang: data.aceLang,
          at: Date.now()
        });
        pending.delete(data.id);
        done(true);
      }
    }
  });
  function requestBridge(timeoutMs = 400) {
    return new Promise((resolve) => {
      const id = ++seq;
      const timer = setTimeout(() => {
        pending.delete(id);
        resolve(false);
      }, timeoutMs);
      pending.set(id, (fresh) => {
        clearTimeout(timer);
        resolve(fresh);
      });
      window.postMessage({ source: SOURCE, type: "request", id }, "*");
    });
  }

  // src/content/index.js
  var emitted = /* @__PURE__ */ new Set();
  var lastHealth = null;
  var debounceTimer = null;
  function pageSubmission(adapter, doc, url, now) {
    const raw = adapter.detect_submission(doc, url, now);
    if (raw) {
      const submission = normalize_submission(adapter, raw);
      if (submission) {
        return { submission, mode: submission.verdict === "accepted" ? "auto" : "manual" };
      }
    }
    if (adapter.capabilities.problem_metadata && adapter.capabilities.manual_sync) {
      const submission = buildManualSubmission(adapter, doc, url, { now });
      if (submission) return { submission, mode: "manual" };
    }
    return { submission: null, mode: null };
  }
  function reportHealth(platform, verdict) {
    lastHealth = { platform, verdict, at: Date.now() };
    console.debug("[codesync] health", lastHealth);
  }
  function emit(submission) {
    sendRuntimeMessage({ type: "ENQUEUE", payload: submission }).then((response) => {
      if (!response || response.ok !== true) {
        const message = response && response.error && response.error.message || "enqueue failed";
        console.debug("[codesync] enqueue rejected:", message);
        emitted.delete(submission.fingerprint);
      }
    }).catch(() => {
      emitted.delete(submission.fingerprint);
    });
  }
  function scan(now = Date.now()) {
    const url = location.href;
    const adapter = matchHost(url);
    if (!adapter || !isAllowedUrl(url)) return;
    if (!adapter.detectPage(url, document)) return;
    if (!adapter.capabilities.submission_detection) return;
    const raw = adapter.detect_submission(document, url, now);
    if (!raw) return;
    if (raw.verdict === "accepted") {
      const submission = normalize_submission(adapter, raw);
      if (!submission || !submission.code || !submission.code.trim()) return;
      if (emitted.has(submission.fingerprint)) return;
      emitted.add(submission.fingerprint);
      emit(submission);
      return;
    }
    if (raw.verdict === "rejected" || raw.verdict === "pending") {
      reportHealth(adapter.id, raw.verdict);
    }
  }
  function scanFresh() {
    requestBridge().then(scan);
  }
  function scheduleScan(delay = 400) {
    if (debounceTimer) return;
    debounceTimer = setTimeout(() => {
      debounceTimer = null;
      scanFresh();
    }, delay);
  }
  async function handleSyncPage() {
    const url = location.href;
    const adapter = matchHost(url);
    if (!adapter || !isAllowedUrl(url)) {
      return ok({ submission: null, reason: "unsupported_host" });
    }
    if (!adapter.detectPage(url, document)) {
      return ok({ submission: null, reason: "unsupported_page", platform: adapter.id });
    }
    await requestBridge(400);
    const found = pageSubmission(adapter, document, url, Date.now());
    if (!found.submission) {
      return ok({ submission: null, reason: "nothing_found", platform: adapter.id });
    }
    if (!found.submission.code || !found.submission.code.trim()) {
      return ok({ submission: null, reason: "nothing_found", platform: adapter.id });
    }
    if (found.mode !== "auto" && found.submission.verdict !== "accepted") {
      found.submission.verdict = "manual";
    }
    return ok({
      submission: found.submission,
      mode: found.mode,
      platform: adapter.id,
      capabilities: adapter.capabilities
    });
  }
  function bootstrap() {
    const url = location.href;
    const adapter = matchHost(url);
    if (!adapter || !isAllowedUrl(url)) return;
    chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
      const validation = validateContentMessage(message);
      if (!validation.ok) {
        sendResponse(fail(validation.error.code, validation.error.message));
        return false;
      }
      if (validation.type === "SYNC_PAGE") {
        handleSyncPage().then(sendResponse).catch((err) => sendResponse(fail("SYNC_PAGE_FAILED", err && err.message)));
        return true;
      }
      return false;
    });
    if (typeof MutationObserver !== "undefined" && document.documentElement) {
      const observer = new MutationObserver(() => scheduleScan(400));
      observer.observe(document.documentElement, {
        subtree: true,
        childList: true,
        characterData: true
      });
    }
    scanFresh();
    for (const delay of [1500, 4e3, 1e4]) {
      setTimeout(() => scanFresh(), delay);
    }
  }
  bootstrap();
})();
