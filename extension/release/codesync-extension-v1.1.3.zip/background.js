(() => {
  // src/shared/config.js
  var DEFAULT_API_BASE_URL = "http://127.0.0.1:8000";
  var API_PREFIX = "/api/v1";
  var STORAGE_KEYS = {
    QUEUE: "codesync.queue",
    SETTINGS: "codesync.settings",
    PAUSED: "codesync.paused",
    CONNECTION: "codesync.connection",
    HISTORY: "codesync.history",
    LAST_SYNC: "codesync.lastSync",
    PLATFORMS: "codesync.platforms"
  };
  var PLATFORM_IDS = ["leetcode", "geeksforgeeks", "codechef", "neetcode"];
  var VERDICTS = ["accepted", "rejected", "pending", "manual", "unknown"];
  var MAX_ATTEMPTS = 5;
  var BACKOFF = { base: 2, factor: 2, cap: 300 };
  var JOB_POLL = { min: 3, max: 30, limit: 10 };
  var ALARM = { name: "codesync.tick", periodMinutes: 0.5 };
  var REQUEST_TIMEOUT_MS = 15e3;
  var HISTORY_LIMIT = 200;
  var BADGE_COLORS = {
    ok: "#16a34a",
    failed: "#dc2626",
    paused: "#6b7280",
    noToken: "#f59e0b"
  };
  function defaultSettings() {
    return { apiBaseUrl: DEFAULT_API_BASE_URL, apiToken: "" };
  }

  // src/shared/api.js
  var ApiError = class extends Error {
    constructor(code, message, { status = null, cause = null } = {}) {
      super(message);
      this.name = "ApiError";
      this.code = code;
      this.status = status;
      if (cause) this.cause = cause;
    }
  };
  function normalizeError(body, status, statusText = "") {
    const fallbackCode = `HTTP_${status}`;
    const detail = body && typeof body === "object" ? body.detail : void 0;
    if (detail && typeof detail === "object" && !Array.isArray(detail)) {
      const code = typeof detail.code === "string" && detail.code ? detail.code : fallbackCode;
      const message2 = typeof detail.message === "string" && detail.message ? detail.message : `Request failed with status ${status}`;
      return { code, message: message2 };
    }
    if (typeof detail === "string" && detail) {
      return { code: fallbackCode, message: detail };
    }
    const message = statusText ? `${status} ${statusText}` : `Request failed with status ${status}`;
    return { code: fallbackCode, message };
  }
  function buildUrl(baseUrl, path) {
    const base = String(baseUrl || "").replace(/\/+$/, "");
    if (!base) throw new ApiError("NO_BASE_URL", "api base url is not configured");
    const suffix = path.startsWith("/") ? path : `/${path}`;
    return `${base}${API_PREFIX}${suffix}`;
  }
  function isAbortError(err) {
    return err && (err.name === "AbortError" || err.name === "TimeoutError" || err.code === 20 || err.code === "ABORT_ERR");
  }
  async function apiRequest(path, {
    method = "GET",
    baseUrl,
    token = null,
    body,
    headers = {},
    timeoutMs = REQUEST_TIMEOUT_MS,
    fetchImpl,
    signal
  } = {}) {
    const url = buildUrl(baseUrl, path);
    const doFetch = fetchImpl || (typeof globalThis.fetch === "function" ? globalThis.fetch.bind(globalThis) : null);
    if (!doFetch) throw new ApiError("NO_FETCH", "fetch is unavailable");
    const controller = new AbortController();
    let timedOut = false;
    let externallyAborted = false;
    const timer = setTimeout(() => {
      timedOut = true;
      controller.abort();
    }, timeoutMs);
    const onExternalAbort = () => {
      externallyAborted = true;
      controller.abort();
    };
    if (signal) {
      if (signal.aborted) onExternalAbort();
      else signal.addEventListener("abort", onExternalAbort, { once: true });
    }
    const finalHeaders = { Accept: "application/json", ...headers };
    if (token) finalHeaders.Authorization = `Bearer ${token}`;
    let payload;
    if (body !== void 0) {
      payload = JSON.stringify(body);
      finalHeaders["Content-Type"] = "application/json";
    }
    let response;
    try {
      response = await doFetch(url, {
        method,
        headers: finalHeaders,
        body: payload,
        signal: controller.signal
      });
    } catch (err) {
      if (timedOut) throw new ApiError("TIMEOUT", `request timed out after ${timeoutMs}ms`, { cause: err });
      if (externallyAborted) throw new ApiError("ABORTED", "request aborted", { cause: err });
      if (isAbortError(err)) throw new ApiError("ABORTED", "request aborted", { cause: err });
      throw new ApiError("NETWORK", err && err.message ? err.message : "network request failed", { cause: err });
    } finally {
      clearTimeout(timer);
      if (signal) signal.removeEventListener("abort", onExternalAbort);
    }
    if (!response.ok) {
      let parsed = null;
      const text2 = await response.text().catch(() => "");
      if (text2) {
        try {
          parsed = JSON.parse(text2);
        } catch {
          parsed = null;
        }
      }
      const { code, message } = normalizeError(parsed, response.status, response.statusText);
      throw new ApiError(code, message, { status: response.status });
    }
    const text = await response.text().catch(() => "");
    if (!text) return null;
    try {
      return JSON.parse(text);
    } catch (err) {
      throw new ApiError("BAD_RESPONSE", "response body was not valid JSON", { status: response.status, cause: err });
    }
  }
  function qs(params = {}) {
    const search = new URLSearchParams();
    for (const [key, value] of Object.entries(params)) {
      if (value === void 0 || value === null || value === "") continue;
      search.set(key, String(value));
    }
    const str = search.toString();
    return str ? `?${str}` : "";
  }
  function createApi({ baseUrl, token = null, fetchImpl, timeoutMs } = {}) {
    const call = (path, opts = {}) => apiRequest(path, { baseUrl, token, fetchImpl, timeoutMs, ...opts });
    return {
      health: () => call("/health"),
      authMe: () => call("/auth/me"),
      // Validate a GitHub PAT server-side; returns { api_token, github_login }.
      connectWithPat: (gitHubToken) => call("/auth/pat", { method: "POST", body: { token: gitHubToken } }),
      createSubmission: (submission) => call("/submissions", { method: "POST", body: submission }),
      listSubmissions: (params = {}) => call(`/submissions${qs(params)}`),
      createSync: (submissionId) => call("/sync", { method: "POST", body: { submission_id: submissionId } }),
      listSync: (params = {}) => call(`/sync${qs(params)}`),
      getSync: (id) => call(`/sync/${id}`),
      retrySync: (id) => call(`/sync/${id}/retry`, { method: "POST" }),
      getSettings: () => call("/settings"),
      updateSettings: (patch) => call("/settings", { method: "PATCH", body: patch }),
      getPlatforms: () => call("/platforms"),
      setPlatform: (id, enabled) => call(`/platforms/${encodeURIComponent(id)}`, { method: "PUT", body: { enabled } }),
      listRepos: (params = {}) => call(`/repos${qs(params)}`),
      createRepo: (payload) => call("/repos", { method: "POST", body: payload }),
      getStats: () => call("/stats"),
      deleteAccount: () => call("/account", { method: "DELETE" })
    };
  }
  function toSubmissionPayload(submission) {
    return {
      platform: submission.platform,
      title: submission.title,
      language: submission.language,
      code: submission.code,
      external_id: submission.external_id,
      problem_id: submission.problem_id,
      url: submission.url,
      verdict: submission.verdict,
      submitted_at: submission.submitted_at,
      metadata: submission.metadata
    };
  }

  // src/shared/sha256.js
  var K = new Uint32Array([
    1116352408,
    1899447441,
    3049323471,
    3921009573,
    961987163,
    1508970993,
    2453635748,
    2870763221,
    3624381080,
    310598401,
    607225278,
    1426881987,
    1925078388,
    2162078206,
    2614888103,
    3248222580,
    3835390401,
    4022224774,
    264347078,
    604807628,
    770255983,
    1249150122,
    1555081692,
    1996064986,
    2554220882,
    2821834349,
    2952996808,
    3210313671,
    3336571891,
    3584528711,
    113926993,
    338241895,
    666307205,
    773529912,
    1294757372,
    1396182291,
    1695183700,
    1986661051,
    2177026350,
    2456956037,
    2730485921,
    2820302411,
    3259730800,
    3345764771,
    3516065817,
    3600352804,
    4094571909,
    275423344,
    430227734,
    506948616,
    659060556,
    883997877,
    958139571,
    1322822218,
    1537002063,
    1747873779,
    1955562222,
    2024104815,
    2227730452,
    2361852424,
    2428436474,
    2756734187,
    3204031479,
    3329325298
  ]);

  // src/shared/schema.js
  var SUBMISSION_FIELDS = [
    "platform",
    "title",
    "problem_id",
    "url",
    "language",
    "code",
    "external_id",
    "verdict",
    "submitted_at",
    "metadata",
    "fingerprint"
  ];
  var FINGERPRINT_RE = /^[0-9a-f]{64}$/;
  var ISO_RE = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d{1,6})?(Z|[+-]\d{2}:\d{2})$/;
  function isPlainObject(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value) && Object.getPrototypeOf(value) === Object.prototype;
  }
  function checkType(errors, field, value, type, { nullable = false, min, max } = {}) {
    if (value === null || value === void 0) {
      if (nullable) return;
      errors.push(`${field} is required`);
      return;
    }
    if (typeof value !== type) {
      errors.push(`${field} must be a ${type}`);
      return;
    }
    if (min !== void 0 && value.length < min) errors.push(`${field} is too short`);
    if (max !== void 0 && value.length > max) errors.push(`${field} is too long`);
  }
  function validateSubmission(submission) {
    if (!isPlainObject(submission)) {
      return { ok: false, error: { code: "INVALID_SUBMISSION", message: "submission must be an object" } };
    }
    const keys = Object.keys(submission).sort();
    const expected = [...SUBMISSION_FIELDS].sort();
    if (keys.length !== expected.length || keys.some((k, i) => k !== expected[i])) {
      const missing = expected.filter((k) => !(k in submission));
      const extra = keys.filter((k) => !expected.includes(k));
      const parts = [];
      if (missing.length) parts.push(`missing: ${missing.join(", ")}`);
      if (extra.length) parts.push(`unexpected: ${extra.join(", ")}`);
      return {
        ok: false,
        error: { code: "INVALID_SUBMISSION", message: `submission fields mismatch (${parts.join("; ")})` }
      };
    }
    const errors = [];
    if (!PLATFORM_IDS.includes(submission.platform)) errors.push("platform is not supported");
    checkType(errors, "title", submission.title, "string", { min: 1, max: 500 });
    checkType(errors, "language", submission.language, "string", { min: 1, max: 64 });
    checkType(errors, "code", submission.code, "string", { nullable: true, max: 5e5 });
    checkType(errors, "problem_id", submission.problem_id, "string", { nullable: true, max: 120 });
    checkType(errors, "external_id", submission.external_id, "string", { nullable: true, max: 120 });
    checkType(errors, "url", submission.url, "string", { nullable: true, max: 1e3 });
    if (typeof submission.url === "string" && !/^https?:\/\//.test(submission.url)) {
      errors.push("url must be http(s)");
    }
    if (!VERDICTS.includes(submission.verdict)) errors.push("verdict is not allowed");
    if (submission.submitted_at !== null) {
      if (typeof submission.submitted_at !== "string" || !ISO_RE.test(submission.submitted_at) || Number.isNaN(Date.parse(submission.submitted_at))) {
        errors.push("submitted_at must be an ISO8601 string or null");
      }
    }
    if (submission.metadata !== null && !isPlainObject(submission.metadata)) {
      errors.push("metadata must be an object or null");
    }
    if (typeof submission.fingerprint !== "string" || !FINGERPRINT_RE.test(submission.fingerprint)) {
      errors.push("fingerprint must be a 64-char lowercase hex sha256");
    }
    if (errors.length) {
      return { ok: false, error: { code: "INVALID_SUBMISSION", message: errors[0] } };
    }
    return { ok: true };
  }
  function emptyPayload(payload) {
    if (!isPlainObject(payload)) return "payload must be an object";
    if (Object.keys(payload).length !== 0) return "payload must be an empty object";
    return null;
  }
  function submissionPayload(payload) {
    const result = validateSubmission(payload);
    return result.ok ? null : result.error.message;
  }
  function manualPayload(payload) {
    const base = submissionPayload(payload);
    if (base) return base;
    if (payload.verdict !== "manual") return 'verdict must be "manual"';
    return null;
  }
  function pausedPayload(payload) {
    if (!isPlainObject(payload)) return "payload must be an object";
    const keys = Object.keys(payload).sort();
    if (keys.length !== 1 || keys[0] !== "paused") return "payload must be exactly {paused}";
    if (typeof payload.paused !== "boolean") return "paused must be a boolean";
    return null;
  }
  function fingerprintPayload(payload) {
    if (!isPlainObject(payload)) return "payload must be an object";
    const keys = Object.keys(payload).sort();
    if (keys.length !== 1 || keys[0] !== "fingerprint") return "payload must be exactly {fingerprint}";
    if (typeof payload.fingerprint !== "string" || !FINGERPRINT_RE.test(payload.fingerprint)) {
      return "fingerprint must be a 64-char lowercase hex sha256";
    }
    return null;
  }
  function settingsPayload(payload) {
    if (!isPlainObject(payload)) return "payload must be an object";
    const keys = Object.keys(payload);
    if (keys.length === 0) return "settings must include at least one field";
    const allowed = ["apiBaseUrl", "apiToken"];
    const unknown = keys.filter((k) => !allowed.includes(k));
    if (unknown.length) return `unexpected settings field: ${unknown[0]}`;
    if ("apiBaseUrl" in payload) {
      if (typeof payload.apiBaseUrl !== "string" || !/^https?:\/\/[^\s]+$/.test(payload.apiBaseUrl)) {
        return "apiBaseUrl must be an http(s) url";
      }
    }
    if ("apiToken" in payload) {
      if (typeof payload.apiToken !== "string" || payload.apiToken.length > 500) {
        return "apiToken must be a string of at most 500 chars";
      }
    }
    return null;
  }
  var MESSAGE_SPECS = {
    PING: { validate: emptyPayload },
    GET_STATE: { validate: emptyPayload },
    ENQUEUE: { validate: submissionPayload },
    SET_PAUSED: { validate: pausedPayload },
    CLEAR_QUEUE: { validate: emptyPayload },
    SYNC_NOW: { validate: emptyPayload },
    SUBMIT_MANUAL: { validate: manualPayload },
    GET_SETTINGS: { validate: emptyPayload },
    SET_SETTINGS: { validate: settingsPayload },
    TEST_CONNECTION: { validate: emptyPayload },
    REMOVE_ITEM: { validate: fingerprintPayload },
    RETRY_ITEM: { validate: fingerprintPayload }
  };
  function validateAgainst(specs, message) {
    if (!isPlainObject(message)) {
      return { ok: false, error: { code: "INVALID_MESSAGE", message: "message must be an object" } };
    }
    const keys = Object.keys(message).sort();
    if (keys.length !== 2 || keys[0] !== "payload" || keys[1] !== "type") {
      return {
        ok: false,
        error: { code: "INVALID_MESSAGE", message: "message must be exactly {type, payload}" }
      };
    }
    const spec = specs[message.type];
    if (!spec) {
      return { ok: false, error: { code: "UNKNOWN_MESSAGE", message: `unknown message type: ${message.type}` } };
    }
    const payloadError = spec.validate(message.payload);
    if (payloadError) {
      return { ok: false, error: { code: "INVALID_PAYLOAD", message: payloadError } };
    }
    return { ok: true, type: message.type, payload: message.payload };
  }
  function validateMessage(message) {
    return validateAgainst(MESSAGE_SPECS, message);
  }
  function ok(data = {}) {
    return { ok: true, ...data };
  }
  function fail(code, message) {
    return { ok: false, error: { code, message } };
  }

  // src/shared/queue.js
  function computeBackoff(attempt, { base = BACKOFF.base, factor = BACKOFF.factor, cap = BACKOFF.cap, jitter = true, rng = Math.random } = {}) {
    let n = attempt < 1 ? 1 : attempt;
    let delay = Math.min(cap, base * factor ** (n - 1));
    if (jitter) {
      delay = delay / 2 + rng() * (delay / 2);
    }
    return Math.max(0, Math.min(cap, delay));
  }
  function shouldRetry(attemptsMade, maxAttempts = MAX_ATTEMPTS) {
    return attemptsMade < maxAttempts;
  }
  function computePollDelay(attempt) {
    const n = attempt < 1 ? 1 : attempt;
    return Math.min(JOB_POLL.max, JOB_POLL.min * 2 ** (n - 1));
  }
  function nextAttemptAt(attempts, now, opts) {
    return now + Math.round(computeBackoff(attempts, opts) * 1e3);
  }
  function enqueueItem(queue, submission, { now = Date.now() } = {}) {
    const list = Array.isArray(queue) ? queue : [];
    const fingerprint = submission.fingerprint;
    const existing = list.find((item2) => item2.fingerprint === fingerprint);
    if (existing) {
      if (existing.state === "done") {
        return {
          queue: list.filter((item2) => item2.fingerprint !== fingerprint),
          deduped: true,
          dropped: existing,
          added: null
        };
      }
      return { queue: list, deduped: true, dropped: null, added: null };
    }
    const item = {
      fingerprint,
      submission,
      state: "pending",
      attempts: 0,
      next_attempt_at: now,
      last_error: null,
      job_id: null,
      created_at: now
    };
    return { queue: [...list, item], deduped: false, dropped: null, added: item };
  }
  function removeItem(queue, fingerprint) {
    const list = Array.isArray(queue) ? queue : [];
    const removed = list.find((item) => item.fingerprint === fingerprint) || null;
    return {
      queue: removed ? list.filter((item) => item.fingerprint !== fingerprint) : list,
      removed
    };
  }
  function updateItem(queue, fingerprint, patch) {
    return (Array.isArray(queue) ? queue : []).map(
      (item) => item.fingerprint === fingerprint ? { ...item, ...patch } : item
    );
  }
  function selectDue(queue, now = Date.now()) {
    return (Array.isArray(queue) ? queue : []).filter(
      (item) => item.state === "pending" && item.next_attempt_at <= now
    );
  }
  function selectPolls(queue, now = Date.now()) {
    return (Array.isArray(queue) ? queue : []).filter(
      (item) => item.state === "syncing" && item.job_id != null && item.next_attempt_at <= now
    );
  }
  function summarize(queue) {
    const list = Array.isArray(queue) ? queue : [];
    const counts = { pending: 0, syncing: 0, done: 0, failed: 0 };
    for (const item of list) {
      if (counts[item.state] !== void 0) counts[item.state] += 1;
    }
    return {
      ...counts,
      queueLength: list.length,
      pendingTotal: counts.pending + counts.syncing
    };
  }
  function markPendingRetry(item, now = Date.now()) {
    return {
      ...item,
      state: "pending",
      attempts: 0,
      polls: 0,
      next_attempt_at: now,
      last_error: null
    };
  }

  // src/shared/hostallow.js
  var PLATFORM_HOSTS = {
    leetcode: ["leetcode.com"],
    geeksforgeeks: ["geeksforgeeks.org"],
    codechef: ["codechef.com"],
    neetcode: ["neetcode.io"]
  };
  function hostsForPlatform(platformId) {
    return PLATFORM_HOSTS[platformId] || [];
  }
  function platformForUrl(url) {
    try {
      const host = new URL(url).hostname.toLowerCase().replace(/\.$/, "");
      const match = PLATFORM_IDS.find(
        (id) => hostsForPlatform(id).some((allowed) => host === allowed || host.endsWith(`.${allowed}`))
      );
      return match || null;
    } catch {
      return null;
    }
  }
  function isPlatformUrl(platform, url) {
    if (!PLATFORM_IDS.includes(platform)) return false;
    if (!url) return true;
    return platformForUrl(url) === platform;
  }

  // src/background/service-worker.js
  var running = false;
  async function storageGet(key, fallback) {
    try {
      const result = await chrome.storage.local.get(key);
      if (result && Object.prototype.hasOwnProperty.call(result, key)) return result[key];
      return fallback;
    } catch {
      return fallback;
    }
  }
  async function storageSet(key, value) {
    try {
      await chrome.storage.local.set({ [key]: value });
    } catch (err) {
      console.error("[codesync] storage write failed", err);
    }
  }
  async function loadQueue() {
    const queue = await storageGet(STORAGE_KEYS.QUEUE, []);
    return Array.isArray(queue) ? queue : [];
  }
  async function saveQueue(queue) {
    await storageSet(STORAGE_KEYS.QUEUE, queue);
  }
  async function loadSettings() {
    const stored = await storageGet(STORAGE_KEYS.SETTINGS, null);
    return { ...defaultSettings(), ...stored && typeof stored === "object" ? stored : {} };
  }
  async function loadPaused() {
    return await storageGet(STORAGE_KEYS.PAUSED, false) === true;
  }
  async function loadConnection() {
    const conn = await storageGet(STORAGE_KEYS.CONNECTION, null);
    return conn && typeof conn === "object" ? conn : { connected: false, github_login: null, lastError: null, checked_at: null };
  }
  async function loadHistory() {
    const history = await storageGet(STORAGE_KEYS.HISTORY, []);
    return Array.isArray(history) ? history : [];
  }
  async function loadLastSync() {
    const value = await storageGet(STORAGE_KEYS.LAST_SYNC, null);
    return value && typeof value === "object" ? value : null;
  }
  async function loadPlatformsCache() {
    const value = await storageGet(STORAGE_KEYS.PLATFORMS, null);
    return value && typeof value === "object" && value.platforms ? value : null;
  }
  async function setConnection(patch) {
    const conn = await loadConnection();
    await storageSet(STORAGE_KEYS.CONNECTION, { ...conn, ...patch, checked_at: Date.now() });
  }
  async function pushHistory(entry) {
    const history = await loadHistory();
    const next = [entry, ...history].slice(0, HISTORY_LIMIT);
    await storageSet(STORAGE_KEYS.HISTORY, next);
  }
  function normalizeApiError(err) {
    if (err instanceof ApiError) return { code: err.code, message: err.message };
    return {
      code: "UNKNOWN",
      message: err && err.message || String(err)
    };
  }
  function isRetryable(error) {
    if (["NETWORK", "TIMEOUT", "ABORTED"].includes(error.code)) return true;
    if (error.code === "HTTP_429") return true;
    return /^HTTP_5\d\d$/.test(error.code);
  }
  async function refreshPlatformsCache(api, force = false) {
    const cache = await loadPlatformsCache();
    const fresh = cache && Date.now() - cache.at < 5 * 60 * 1e3;
    if (fresh && !force) return cache;
    try {
      const response = await api.getPlatforms();
      const list = response && response.platforms || [];
      const platforms = {};
      for (const item of list) platforms[item.id] = item.enabled !== false;
      const next = { platforms, at: Date.now() };
      await storageSet(STORAGE_KEYS.PLATFORMS, next);
      return next;
    } catch {
      return cache;
    }
  }
  async function updateBadge() {
    if (typeof chrome === "undefined" || !chrome.action) return;
    try {
      const [queue, settings, paused] = await Promise.all([
        loadQueue(),
        loadSettings(),
        loadPaused()
      ]);
      const counts = summarize(queue);
      let text = counts.pendingTotal > 0 ? String(counts.pendingTotal) : "";
      let color = BADGE_COLORS.ok;
      if (!settings.apiToken) {
        text = "!";
        color = BADGE_COLORS.noToken;
      } else if (paused) {
        color = BADGE_COLORS.paused;
      } else if (counts.failed > 0) {
        color = BADGE_COLORS.failed;
      }
      chrome.action.setBadgeText({ text: text.slice(0, 4) });
      chrome.action.setBadgeBackgroundColor({ color });
    } catch {
    }
  }
  async function stampNoToken(queue) {
    let changed = false;
    const next = queue.map((item) => {
      if (item.state === "pending" && (!item.last_error || item.last_error.code !== "NO_TOKEN")) {
        changed = true;
        return {
          ...item,
          last_error: { code: "NO_TOKEN", message: "API token not configured" }
        };
      }
      return item;
    });
    if (changed) await saveQueue(next);
    return next;
  }
  async function handlePostFailure(queue, item, err) {
    const error = normalizeApiError(err);
    await setConnection(
      error.code === "HTTP_401" || error.code === "HTTP_403" ? { connected: false, lastError: error } : { lastError: error }
    );
    const attempts = item.attempts + 1;
    if (isRetryable(error) && shouldRetry(attempts, MAX_ATTEMPTS)) {
      return updateItem(queue, item.fingerprint, {
        state: "pending",
        attempts,
        last_error: error,
        next_attempt_at: nextAttemptAt(attempts, Date.now())
      });
    }
    return updateItem(queue, item.fingerprint, {
      state: "failed",
      attempts,
      last_error: error
    });
  }
  async function processDueItem(api, queue0, item) {
    let queue = updateItem(queue0, item.fingerprint, {
      state: "syncing",
      next_attempt_at: Date.now() + 12e4
    });
    await saveQueue(queue);
    try {
      const response = await api.createSubmission(toSubmissionPayload(item.submission));
      await setConnection({ connected: true, lastError: null });
      const jobId = response && response.sync_job_id != null ? response.sync_job_id : null;
      if (jobId) {
        queue = updateItem(queue, item.fingerprint, {
          state: "syncing",
          job_id: jobId,
          polls: 0,
          last_error: null,
          next_attempt_at: Date.now() + computePollDelay(1) * 1e3
        });
      } else {
        queue = removeItem(queue, item.fingerprint).queue;
        await pushHistory({
          fingerprint: item.fingerprint,
          platform: item.submission.platform,
          title: item.submission.title,
          state: response && response.duplicate ? "duplicate" : "submitted",
          path: null,
          commit_sha: null,
          repo: null,
          at: Date.now()
        });
      }
      await saveQueue(queue);
      return queue;
    } catch (err) {
      queue = await handlePostFailure(queue, item, err);
      await saveQueue(queue);
      return queue;
    }
  }
  async function completeJob(queue, item, job) {
    queue = removeItem(queue, item.fingerprint).queue;
    await saveQueue(queue);
    const lastSync = {
      at: Date.now(),
      path: job.file_path || null,
      commit_sha: job.commit_sha || null,
      repo: job.repo_full_name || null
    };
    await storageSet(STORAGE_KEYS.LAST_SYNC, lastSync);
    await pushHistory({
      fingerprint: item.fingerprint,
      platform: item.submission.platform,
      title: item.submission.title,
      state: "synced",
      path: lastSync.path,
      commit_sha: lastSync.commit_sha,
      repo: lastSync.repo,
      at: lastSync.at
    });
    return queue;
  }
  async function processPollItem(api, queue0, item) {
    let queue = queue0;
    try {
      const job = await api.getSync(item.job_id);
      await setConnection({ connected: true, lastError: null });
      if (job && job.state === "SYNCED") {
        return await completeJob(queue, item, job);
      }
      if (job && job.state === "FAILED") {
        queue = updateItem(queue, item.fingerprint, {
          state: "failed",
          last_error: {
            code: job.error_code || "SYNC_FAILED",
            message: job.last_error || "sync job failed"
          }
        });
        await saveQueue(queue);
        return queue;
      }
      const polls = (item.polls || 0) + 1;
      if (polls >= JOB_POLL.limit) {
        queue = updateItem(queue, item.fingerprint, {
          state: "failed",
          polls,
          last_error: {
            code: "POLL_TIMEOUT",
            message: `sync job did not finish after ${JOB_POLL.limit} polls`
          }
        });
      } else {
        queue = updateItem(queue, item.fingerprint, {
          polls,
          next_attempt_at: Date.now() + computePollDelay(polls) * 1e3
        });
      }
      await saveQueue(queue);
      return queue;
    } catch (err) {
      const error = normalizeApiError(err);
      await setConnection(
        error.code === "HTTP_401" || error.code === "HTTP_403" ? { connected: false, lastError: error } : { lastError: error }
      );
      const attempts = item.attempts + 1;
      if (isRetryable(error) && shouldRetry(attempts, MAX_ATTEMPTS)) {
        queue = updateItem(queue, item.fingerprint, {
          attempts,
          last_error: error,
          next_attempt_at: nextAttemptAt(attempts, Date.now())
        });
      } else {
        queue = updateItem(queue, item.fingerprint, {
          state: "failed",
          attempts,
          last_error: error
        });
      }
      await saveQueue(queue);
      return queue;
    }
  }
  async function worker({ force = false } = {}) {
    if (running) return 0;
    running = true;
    let processed = 0;
    try {
      const paused = await loadPaused();
      if (paused && !force) {
        await updateBadge();
        return 0;
      }
      const settings = await loadSettings();
      let queue = await loadQueue();
      if (!settings.apiToken) {
        queue = await stampNoToken(queue);
        await updateBadge();
        return 0;
      }
      const api = createApi({ baseUrl: settings.apiBaseUrl, token: settings.apiToken });
      await refreshPlatformsCache(api);
      const now = Date.now();
      const duePending = force ? queue.filter((i) => i.state === "pending") : selectDue(queue, now);
      const duePolls = selectPolls(queue, now);
      for (const seed of duePending) {
        const item = queue.find((i) => i.fingerprint === seed.fingerprint);
        if (!item || item.state !== "pending" || item.job_id != null) continue;
        processed += 1;
        queue = await processDueItem(api, queue, item);
      }
      for (const seed of duePolls) {
        const item = queue.find((i) => i.fingerprint === seed.fingerprint);
        if (!item || item.state !== "syncing" || item.job_id == null) continue;
        if (item.next_attempt_at > Date.now()) continue;
        processed += 1;
        queue = await processPollItem(api, queue, item);
      }
      return processed;
    } catch (err) {
      console.error("[codesync] worker error", err);
      return processed;
    } finally {
      running = false;
      await updateBadge();
    }
  }
  function kick() {
    worker().catch((err) => console.error("[codesync] worker failed", err));
  }
  async function enqueueSubmission(submission) {
    if (!isPlatformUrl(submission.platform, submission.url)) {
      return fail("HOST_NOT_ALLOWED", "submission url is outside the allowed platform hosts");
    }
    const cache = await loadPlatformsCache();
    if (cache && cache.platforms[submission.platform] === false) {
      return fail("PLATFORM_DISABLED", `${submission.platform} is disabled in platform settings`);
    }
    const queue = await loadQueue();
    const result = enqueueItem(queue, submission, { now: Date.now() });
    await saveQueue(result.queue);
    if (result.dropped) {
      await pushHistory({
        fingerprint: result.dropped.fingerprint,
        platform: result.dropped.submission.platform,
        title: result.dropped.submission.title,
        state: "duplicate",
        path: null,
        commit_sha: null,
        repo: null,
        at: Date.now()
      });
    }
    kick();
    return ok({ deduped: result.deduped, queueLength: result.queue.length });
  }
  async function getState() {
    const [queue, settings, paused, connection, history, lastSync] = await Promise.all([
      loadQueue(),
      loadSettings(),
      loadPaused(),
      loadConnection(),
      loadHistory(),
      loadLastSync()
    ]);
    const counts = summarize(queue);
    const failedItem = queue.find((item) => item.state === "failed" && item.last_error);
    const lastError = connection.lastError || (failedItem ? failedItem.last_error : null) || null;
    return ok({
      connected: Boolean(settings.apiToken) && connection.connected === true,
      paused,
      queueLength: counts.queueLength,
      pending: counts.pending + counts.syncing,
      failed: counts.failed,
      syncing: running,
      lastError,
      apiBaseUrl: settings.apiBaseUrl,
      stats: {
        pending: counts.pending,
        syncing: counts.syncing,
        failed: counts.failed,
        synced: history.filter((entry) => entry.state === "synced").length,
        total: history.length
      },
      queue: queue.map((item) => ({
        fingerprint: item.fingerprint,
        platform: item.submission.platform,
        title: item.submission.title,
        language: item.submission.language,
        state: item.state,
        attempts: item.attempts,
        next_attempt_at: item.next_attempt_at,
        created_at: item.created_at,
        job_id: item.job_id,
        last_error: item.last_error,
        submission: item.submission
      })),
      lastSync,
      history: history.slice(0, 20)
    });
  }
  async function testConnection() {
    const settings = await loadSettings();
    if (!settings.apiToken) {
      return fail("NO_TOKEN", "No API token configured");
    }
    const api = createApi({ baseUrl: settings.apiBaseUrl, token: settings.apiToken });
    try {
      const me = await api.authMe();
      const githubLogin = me && (me.github_login || me.user && me.user.github_login) || null;
      await setConnection({ connected: true, github_login: githubLogin, lastError: null });
      await refreshPlatformsCache(api, true);
      return ok({ connected: true, github_login: githubLogin });
    } catch (err) {
      const error = normalizeApiError(err);
      await setConnection({
        connected: false,
        github_login: null,
        lastError: error
      });
      return fail(error.code, error.message);
    }
  }
  async function scheduleAuthCheck() {
    const settings = await loadSettings();
    if (!settings.apiToken) return;
    const api = createApi({ baseUrl: settings.apiBaseUrl, token: settings.apiToken });
    try {
      const me = await api.authMe();
      const githubLogin = me && (me.github_login || me.user && me.user.github_login) || null;
      await setConnection({ connected: true, github_login: githubLogin, lastError: null });
    } catch (err) {
      const error = normalizeApiError(err);
      await setConnection({ connected: false, github_login: null, lastError: error });
    }
    await refreshPlatformsCache(api, true);
    await updateBadge();
  }
  async function retryItem(fingerprint) {
    const queue = await loadQueue();
    const item = queue.find((entry) => entry.fingerprint === fingerprint);
    if (!item) return fail("NOT_FOUND", "queue item not found");
    const settings = await loadSettings();
    if (item.job_id != null && item.state === "failed" && settings.apiToken) {
      const api = createApi({ baseUrl: settings.apiBaseUrl, token: settings.apiToken });
      try {
        const response = await api.retrySync(item.job_id);
        const jobId = response && response.job ? response.job.id : item.job_id;
        const next2 = updateItem(queue, fingerprint, {
          state: "syncing",
          job_id: jobId,
          polls: 0,
          attempts: 0,
          last_error: null,
          next_attempt_at: Date.now() + computePollDelay(1) * 1e3
        });
        await saveQueue(next2);
        kick();
        return ok({ queueLength: next2.length });
      } catch (err) {
        const error = normalizeApiError(err);
        return fail(error.code, error.message);
      }
    }
    const next = updateItem(queue, fingerprint, markPendingRetry(item, Date.now()));
    await saveQueue(next);
    kick();
    return ok({ queueLength: next.length });
  }
  async function handleMessage(message) {
    const validation = validateMessage(message);
    if (!validation.ok) {
      return fail(validation.error.code, validation.error.message);
    }
    const { type, payload } = validation;
    switch (type) {
      case "PING":
        return ok();
      case "GET_STATE":
        return getState();
      case "ENQUEUE":
      case "SUBMIT_MANUAL":
        return enqueueSubmission(payload);
      case "SET_PAUSED": {
        await storageSet(STORAGE_KEYS.PAUSED, payload.paused);
        if (!payload.paused) kick();
        await updateBadge();
        return ok({ paused: payload.paused });
      }
      case "CLEAR_QUEUE": {
        await saveQueue([]);
        await updateBadge();
        return ok({ queueLength: 0 });
      }
      case "SYNC_NOW": {
        const queue = await loadQueue();
        const now = Date.now();
        const requeued = queue.map(
          (item) => item.state === "pending" ? { ...item, next_attempt_at: now } : item
        );
        await saveQueue(requeued);
        const processed = await worker({ force: true });
        return ok({ processed });
      }
      case "GET_SETTINGS": {
        const settings = await loadSettings();
        return ok({ settings });
      }
      case "SET_SETTINGS": {
        const current = await loadSettings();
        const settings = { ...current, ...payload };
        await storageSet(STORAGE_KEYS.SETTINGS, settings);
        if (payload.apiToken !== void 0 || payload.apiBaseUrl !== void 0) {
          scheduleAuthCheck().catch(() => {
          });
        }
        await updateBadge();
        return ok({ settings });
      }
      case "TEST_CONNECTION":
        return testConnection();
      case "REMOVE_ITEM": {
        const queue = await loadQueue();
        const result = removeItem(queue, payload.fingerprint);
        await saveQueue(result.queue);
        await updateBadge();
        return ok({ queueLength: result.queue.length, removed: Boolean(result.removed) });
      }
      case "RETRY_ITEM":
        return retryItem(payload.fingerprint);
      default:
        return fail("UNKNOWN_MESSAGE", `unknown message type: ${type}`);
    }
  }
  function ensureAlarm() {
    try {
      const result = chrome.alarms.create(ALARM.name, {
        periodInMinutes: ALARM.periodMinutes
      });
      if (result && typeof result.catch === "function") result.catch(() => {
      });
    } catch {
    }
  }
  if (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.onMessage) {
    chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
      handleMessage(message).then(sendResponse).catch((err) => sendResponse(fail("INTERNAL", err && err.message || "internal error")));
      return true;
    });
    chrome.alarms.onAlarm.addListener((alarm) => {
      if (alarm && alarm.name === ALARM.name) kick();
    });
    if (chrome.runtime.onInstalled) {
      chrome.runtime.onInstalled.addListener(() => {
        ensureAlarm();
        kick();
      });
    }
    if (chrome.runtime.onStartup) {
      chrome.runtime.onStartup.addListener(() => {
        ensureAlarm();
        kick();
      });
    }
    ensureAlarm();
    kick();
  }
})();
