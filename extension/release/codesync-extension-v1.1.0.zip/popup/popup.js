(() => {
  // src/shared/config.js
  var API_PREFIX = "/api/v1";
  var REQUEST_TIMEOUT_MS = 15e3;

  // src/shared/api.js
  var ApiError = class extends Error {
    constructor(code, message, { status = null, cause = null } = {}) {
      super(message);
      this.name = "ApiError";
      this.code = code;
      this.status = status;
      if (cause) this.cause = cause;
    }
  };
  function normalizeError(body, status, statusText = "") {
    const fallbackCode = `HTTP_${status}`;
    const detail = body && typeof body === "object" ? body.detail : void 0;
    if (detail && typeof detail === "object" && !Array.isArray(detail)) {
      const code = typeof detail.code === "string" && detail.code ? detail.code : fallbackCode;
      const message2 = typeof detail.message === "string" && detail.message ? detail.message : `Request failed with status ${status}`;
      return { code, message: message2 };
    }
    if (typeof detail === "string" && detail) {
      return { code: fallbackCode, message: detail };
    }
    const message = statusText ? `${status} ${statusText}` : `Request failed with status ${status}`;
    return { code: fallbackCode, message };
  }
  function buildUrl(baseUrl, path) {
    const base = String(baseUrl || "").replace(/\/+$/, "");
    if (!base) throw new ApiError("NO_BASE_URL", "api base url is not configured");
    const suffix = path.startsWith("/") ? path : `/${path}`;
    return `${base}${API_PREFIX}${suffix}`;
  }
  function isAbortError(err) {
    return err && (err.name === "AbortError" || err.name === "TimeoutError" || err.code === 20 || err.code === "ABORT_ERR");
  }
  async function apiRequest(path, {
    method = "GET",
    baseUrl,
    token = null,
    body,
    headers = {},
    timeoutMs = REQUEST_TIMEOUT_MS,
    fetchImpl,
    signal
  } = {}) {
    const url = buildUrl(baseUrl, path);
    const doFetch = fetchImpl || (typeof globalThis.fetch === "function" ? globalThis.fetch.bind(globalThis) : null);
    if (!doFetch) throw new ApiError("NO_FETCH", "fetch is unavailable");
    const controller = new AbortController();
    let timedOut = false;
    let externallyAborted = false;
    const timer = setTimeout(() => {
      timedOut = true;
      controller.abort();
    }, timeoutMs);
    const onExternalAbort = () => {
      externallyAborted = true;
      controller.abort();
    };
    if (signal) {
      if (signal.aborted) onExternalAbort();
      else signal.addEventListener("abort", onExternalAbort, { once: true });
    }
    const finalHeaders = { Accept: "application/json", ...headers };
    if (token) finalHeaders.Authorization = `Bearer ${token}`;
    let payload;
    if (body !== void 0) {
      payload = JSON.stringify(body);
      finalHeaders["Content-Type"] = "application/json";
    }
    let response;
    try {
      response = await doFetch(url, {
        method,
        headers: finalHeaders,
        body: payload,
        signal: controller.signal
      });
    } catch (err) {
      if (timedOut) throw new ApiError("TIMEOUT", `request timed out after ${timeoutMs}ms`, { cause: err });
      if (externallyAborted) throw new ApiError("ABORTED", "request aborted", { cause: err });
      if (isAbortError(err)) throw new ApiError("ABORTED", "request aborted", { cause: err });
      throw new ApiError("NETWORK", err && err.message ? err.message : "network request failed", { cause: err });
    } finally {
      clearTimeout(timer);
      if (signal) signal.removeEventListener("abort", onExternalAbort);
    }
    if (!response.ok) {
      let parsed = null;
      const text2 = await response.text().catch(() => "");
      if (text2) {
        try {
          parsed = JSON.parse(text2);
        } catch {
          parsed = null;
        }
      }
      const { code, message } = normalizeError(parsed, response.status, response.statusText);
      throw new ApiError(code, message, { status: response.status });
    }
    const text = await response.text().catch(() => "");
    if (!text) return null;
    try {
      return JSON.parse(text);
    } catch (err) {
      throw new ApiError("BAD_RESPONSE", "response body was not valid JSON", { status: response.status, cause: err });
    }
  }
  function qs(params = {}) {
    const search = new URLSearchParams();
    for (const [key, value] of Object.entries(params)) {
      if (value === void 0 || value === null || value === "") continue;
      search.set(key, String(value));
    }
    const str = search.toString();
    return str ? `?${str}` : "";
  }
  function createApi({ baseUrl, token = null, fetchImpl, timeoutMs } = {}) {
    const call = (path, opts = {}) => apiRequest(path, { baseUrl, token, fetchImpl, timeoutMs, ...opts });
    return {
      health: () => call("/health"),
      authMe: () => call("/auth/me"),
      createSubmission: (submission) => call("/submissions", { method: "POST", body: submission }),
      listSubmissions: (params = {}) => call(`/submissions${qs(params)}`),
      createSync: (submissionId) => call("/sync", { method: "POST", body: { submission_id: submissionId } }),
      listSync: (params = {}) => call(`/sync${qs(params)}`),
      getSync: (id) => call(`/sync/${id}`),
      retrySync: (id) => call(`/sync/${id}/retry`, { method: "POST" }),
      getSettings: () => call("/settings"),
      updateSettings: (patch) => call("/settings", { method: "PATCH", body: patch }),
      getPlatforms: () => call("/platforms"),
      setPlatform: (id, enabled) => call(`/platforms/${encodeURIComponent(id)}`, { method: "PUT", body: { enabled } }),
      listRepos: (params = {}) => call(`/repos${qs(params)}`),
      createRepo: (payload) => call("/repos", { method: "POST", body: payload }),
      getStats: () => call("/stats"),
      deleteAccount: () => call("/account", { method: "DELETE" })
    };
  }

  // src/shared/sha256.js
  var K = new Uint32Array([
    1116352408,
    1899447441,
    3049323471,
    3921009573,
    961987163,
    1508970993,
    2453635748,
    2870763221,
    3624381080,
    310598401,
    607225278,
    1426881987,
    1925078388,
    2162078206,
    2614888103,
    3248222580,
    3835390401,
    4022224774,
    264347078,
    604807628,
    770255983,
    1249150122,
    1555081692,
    1996064986,
    2554220882,
    2821834349,
    2952996808,
    3210313671,
    3336571891,
    3584528711,
    113926993,
    338241895,
    666307205,
    773529912,
    1294757372,
    1396182291,
    1695183700,
    1986661051,
    2177026350,
    2456956037,
    2730485921,
    2820302411,
    3259730800,
    3345764771,
    3516065817,
    3600352804,
    4094571909,
    275423344,
    430227734,
    506948616,
    659060556,
    883997877,
    958139571,
    1322822218,
    1537002063,
    1747873779,
    1955562222,
    2024104815,
    2227730452,
    2361852424,
    2428436474,
    2756734187,
    3204031479,
    3329325298
  ]);

  // src/shared/schema.js
  function fail(code, message) {
    return { ok: false, error: { code, message } };
  }

  // src/shared/messaging.js
  function runtime() {
    return typeof chrome !== "undefined" && chrome.runtime ? chrome.runtime : null;
  }
  function sendRuntimeMessage(message) {
    const rt = runtime();
    if (!rt) return Promise.resolve(fail("NO_RUNTIME", "chrome.runtime is unavailable"));
    try {
      const result = rt.sendMessage(message);
      if (result && typeof result.then === "function") return result;
      return new Promise((resolve, reject) => {
        try {
          rt.sendMessage(message, (response) => {
            const err = rt.lastError;
            if (err) reject(new Error(err.message));
            else resolve(response);
          });
        } catch (err) {
          reject(err);
        }
      });
    } catch (err) {
      return Promise.resolve(fail("RUNTIME_ERROR", err && err.message ? err.message : "sendMessage failed"));
    }
  }
  function sendTabMessage(tabId, message) {
    if (typeof chrome === "undefined" || !chrome.tabs) {
      return Promise.resolve(fail("NO_TABS", "chrome.tabs is unavailable"));
    }
    try {
      const result = chrome.tabs.sendMessage(tabId, message);
      if (result && typeof result.then === "function") return result;
      return new Promise((resolve, reject) => {
        chrome.tabs.sendMessage(tabId, message, (response) => {
          const err = chrome.runtime.lastError;
          if (err) reject(new Error(err.message));
          else resolve(response);
        });
      });
    } catch (err) {
      return Promise.reject(err);
    }
  }
  async function getActiveTabId() {
    if (typeof chrome === "undefined" || !chrome.tabs) return null;
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    return tabs && tabs.length ? tabs[0].id : null;
  }
  async function request(type, payload = {}) {
    const response = await sendRuntimeMessage({ type, payload });
    if (!response || response.ok !== true) {
      const error = response && response.error || { code: "NO_RESPONSE", message: "no response from background" };
      const err = new Error(error.message || "request failed");
      err.code = error.code || "NO_RESPONSE";
      throw err;
    }
    return response;
  }

  // src/popup/popup.js
  var $ = (id) => document.getElementById(id);
  var currentState = null;
  var toastTimer = null;
  function toast(message, isError = false) {
    const node = $("toast");
    node.textContent = message;
    node.classList.toggle("toast-error", isError);
    node.hidden = false;
    if (toastTimer) clearTimeout(toastTimer);
    toastTimer = setTimeout(() => {
      node.hidden = true;
    }, 2600);
  }
  function shortFingerprint(fingerprint) {
    return `${fingerprint.slice(0, 8)}\u2026${fingerprint.slice(-4)}`;
  }
  function stateLabel(state) {
    if (state === "done") return "synced";
    return state;
  }
  function render(state) {
    currentState = state;
    document.body.classList.toggle("is-paused", state.paused);
    const conn = $("conn");
    conn.textContent = state.connected ? "connected" : "not connected";
    conn.classList.toggle("chip-ok", state.connected);
    conn.classList.toggle("chip-off", !state.connected);
    conn.title = state.apiBaseUrl || "";
    $("stat-pending").textContent = String(state.pending ?? 0);
    $("stat-synced").textContent = String((state.stats && state.stats.synced) ?? 0);
    $("stat-failed").textContent = String(state.failed ?? 0);
    const items = Array.isArray(state.queue) ? state.queue : [];
    const visible = items.slice(0, 6);
    const list = $("queue");
    list.replaceChildren();
    for (const item of visible) {
      const li = document.createElement("li");
      const fp = document.createElement("span");
      fp.className = "fp";
      fp.textContent = shortFingerprint(item.fingerprint);
      const title = document.createElement("span");
      title.className = "title";
      title.textContent = item.title || "(untitled)";
      const chip = document.createElement("span");
      chip.className = `state state-${item.state}`;
      chip.textContent = stateLabel(item.state);
      if (item.last_error) {
        chip.title = `${item.last_error.code}: ${item.last_error.message}`;
      } else if (item.job_id != null) {
        chip.title = `sync job #${item.job_id}`;
      }
      li.append(fp, title, chip);
      list.append(li);
    }
    const empty = $("queue-empty");
    empty.hidden = items.length > 0;
    $("queue-meta").textContent = items.length ? `${items.length} item${items.length === 1 ? "" : "s"}` : "";
    const failedCount = state.failed ?? 0;
    $("btn-clear-failed").disabled = failedCount === 0;
    $("btn-pause").textContent = state.paused ? "Resume" : "Pause";
    const lastSync = $("last-sync");
    if (state.lastSync && (state.lastSync.path || state.lastSync.repo)) {
      const repo = state.lastSync.repo ? `${state.lastSync.repo}` : "";
      const path = state.lastSync.path || "";
      lastSync.textContent = `Last sync: ${path || "done"}${repo ? ` \xB7 ${repo}` : ""}`;
      lastSync.hidden = false;
    } else {
      lastSync.hidden = true;
    }
  }
  async function refresh() {
    try {
      const state = await request("GET_STATE");
      render(state);
      return state;
    } catch (err) {
      toast(err.message, true);
      return null;
    }
  }
  async function syncThisPage() {
    try {
      const tabId = await getActiveTabId();
      if (tabId === null) throw new Error("No active tab");
      const response = await sendTabMessage(tabId, { type: "SYNC_PAGE", payload: {} });
      if (!response || response.ok !== true) {
        throw new Error(response && response.error && response.error.message || "This page is not supported");
      }
      if (!response.submission) {
        const reasons = {
          unsupported_host: "Open a supported platform page first",
          unsupported_page: "This page cannot be synced",
          nothing_found: "No solution code detected on this page"
        };
        toast(reasons[response.reason] || "Nothing to sync on this page");
        return;
      }
      const submission = response.submission;
      let type = "ENQUEUE";
      if (submission.verdict !== "accepted") {
        submission.verdict = "manual";
        type = "SUBMIT_MANUAL";
      }
      const result = await request(type, submission);
      toast(result.deduped ? "Already queued" : "Queued for sync");
      await refresh();
    } catch (err) {
      toast(err.message, true);
    }
  }
  async function syncNow() {
    try {
      const result = await request("SYNC_NOW");
      if (result.processed === 0) {
        toast(currentState && currentState.pending ? "Worker busy or paused" : "Nothing pending");
      } else {
        toast(`Processing ${result.processed} item${result.processed === 1 ? "" : "s"}`);
      }
      await refresh();
    } catch (err) {
      toast(err.message, true);
    }
  }
  async function togglePause() {
    try {
      if (!currentState) return;
      const result = await request("SET_PAUSED", { paused: !currentState.paused });
      toast(result.paused ? "Paused" : "Resumed");
      await refresh();
    } catch (err) {
      toast(err.message, true);
    }
  }
  async function clearFailed() {
    try {
      if (!currentState || !Array.isArray(currentState.queue)) return;
      const failed = currentState.queue.filter((item) => item.state === "failed");
      for (const item of failed) {
        await request("REMOVE_ITEM", { fingerprint: item.fingerprint });
      }
      toast(`Cleared ${failed.length} failed item${failed.length === 1 ? "" : "s"}`);
      await refresh();
    } catch (err) {
      toast(err.message, true);
    }
  }
  async function loadRepoLink() {
    try {
      const settingsResponse = await request("GET_SETTINGS");
      const settings = settingsResponse.settings;
      if (!settings || !settings.apiToken) return;
      const api = createApi({ baseUrl: settings.apiBaseUrl, token: settings.apiToken });
      const remote = await api.getSettings();
      if (remote && remote.repo_full_name) {
        const link = $("repo-link");
        link.href = `https://github.com/${remote.repo_full_name}`;
        link.textContent = remote.repo_full_name;
        link.title = `Open ${remote.repo_full_name} on GitHub`;
        link.hidden = false;
      }
    } catch {
    }
  }
  function bind() {
    $("btn-sync-page").addEventListener("click", syncThisPage);
    $("btn-sync").addEventListener("click", syncNow);
    $("btn-pause").addEventListener("click", togglePause);
    $("btn-clear-failed").addEventListener("click", clearFailed);
    $("btn-options").addEventListener("click", () => {
      chrome.runtime.openOptionsPage();
    });
  }
  async function init() {
    bind();
    await refresh();
    loadRepoLink();
  }
  init();
})();
